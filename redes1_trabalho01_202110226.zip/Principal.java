import controlador.Controlador;
import camadas.*;
import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/*********************************************
Nome: Ana Beatriz Silva e Silva 
Data de inicio: 25/08/2023
data de termino: 05/09/2023
objetivo: Simulando a camada fisica de redes
********************************************/
public class Principal extends Application{

	public static Scene aplicacao;

  @Override
  public void start(Stage primaryStage) throws IOException {
    Controlador control = new Controlador();
    Parent fxmlAplicacao = FXMLLoader.load(getClass().getResource("/tela/Aplicacao.fxml"));
    aplicacao = new Scene(fxmlAplicacao);
    primaryStage.setScene(aplicacao);
    primaryStage.show();
  }//Fim metodo start

  public static void main(String args[]){
    launch(args);
  }//Fim main

}//Fim classe Principal