package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;


/*********************************************
Nome: Ana Beatriz Silva e Silva 
Data de inicio: 25/08/2023
data de termino: 05/09/2023
objetivo: Simulando a camada fisica de redes
********************************************/

public class CamadaReceptora{
  Controlador control;

  public CamadaReceptora(){
    
  }//Fim metodo construtor CamadaReceptora

  public void camadaFisicaReceptora(int quadro[]) {
    int fluxoBrutoDeBits[];
    switch (tipoDeDecodificacao) {
      case 0 : //decodificao binaria
        fluxoBrutoDeBits = camadaFisicaReceptoraDecodificacaoBinaria(quadro);
        camadaDeAplicacaoReceptora(fluxoBrutoDeBits);
        break;
      case 1 : //decodificacao manchester
        fluxoBrutoDeBits = camadaFisicaReceptoraDecodificacaoManchester(quadro);
        camadaDeAplicacaoReceptora(fluxoBrutoDeBits);
        break;
      case 2 : //codificacao manchester diferencial
        fluxoBrutoDeBits = camadaFisicaReceptoraDecodificacaoManchesterDiferencial(quadro);
        camadaDeAplicacaoReceptora(fluxoBrutoDeBits);
        break;
    }//fim do switch case
}//fim metodo CamadaFisicaTransmissora


public void camadaDeAplicacaoReceptora(int quadro[]){ 
  String mensagem = "";
  int c = 0;
  String desinverter = "";
  int j = 0;
  int n = 0;
  String result = "";
  String mensagem2= "";

  // Verifica se o tipo de decodificação é 1 (Manchester) ou 2 (Manchester Diferencial)
  if(tipoDeDecodificacao == 1 || tipoDeDecodificacao == 2){
    while(n < quadro.length * 4){
      c = quadro[j] & 255; // Compara usando o operador 'and' com o valor 11111111 para obter o byte inferior.
      quadro[j] = quadro[j] >> 8; // Desloca 8 bits para a direita para obter o próximo byte.
      mensagem += (char)c; // Converte o byte em um caractere e adiciona à mensagem.

      n++;

      // Inverte a mensagem a cada dois caracteres (para decodificação Manchester).
      if(n % 2 == 0){
        for(int m = mensagem.length() - 1; m >= 0; m--){
          desinverter += mensagem.charAt(m);
        }
        mensagem2 += desinverter;
        desinverter = "";
        mensagem = "";
      }

      // Verifica se já processou 4 bytes e, em seguida, adiciona a mensagem resultante.
      if(n != 0 && n % 4 == 0 && j < quadro.length - 1){
        j++;
      }
      if(n != 0 && n % 4 == 0 || n == quadro.length * 4){
        result = mensagem + result;
        mensagem = "";
      }
    }
    
    // Atribui a mensagem à mensagem2 e chama aplicacaoReceptora com a mensagem resultante.
    mensagem = mensagem2;
    aplicacaoReceptora(mensagem);
  }
  // Tipo de decodificação binária (0)
  else if(tipoDeDecodificacao == 0){
    while(n < quadro.length * 4){
      c = quadro[j] & 255; // Compara usando o operador 'and' com o valor 11111111 para obter o byte inferior.
      quadro[j] = quadro[j] >> 8; // Desloca 8 bits para a direita para obter o próximo byte.
      mensagem += (char)c; // Converte o byte em um caractere e adiciona à mensagem.
      n++;

      // Verifica se já processou 4 bytes e, em seguida, adiciona a mensagem resultante.
      if(n != 0 && n % 4 == 0 && j < quadro.length - 1){
        j++;
      }
      if(n != 0 && n % 4 == 0 || n == quadro.length * 4){
        result = mensagem + result;
        mensagem = "";
      }
    }
    
    // Inverte a mensagem resultante (para decodificação binária) e chama aplicacaoReceptora.
    for(int k = result.length() - 1; k >= 0; k--){
      desinverter += result.charAt(k);
    }
    mensagem = desinverter;
    aplicacaoReceptora(mensagem);
  }
}

public void aplicacaoReceptora(String mensagem){
  // Define a mensagem recebida em algum elemento de controle, como um campo de texto.
  control.mensagemRecebida.setText(mensagem);
  control.mensagemRecebidaTela.setText(mensagem);
}

public int[] camadaFisicaReceptoraDecodificacaoBinaria(int quadro[]){
  int[] temp = new int[quadro.length];
  control.mensagemDecodificada.setText(""); // Limpa o campo de mensagem decodificada.

  // Copia o quadro original para 'temp'.
  for(int i = 0; i < quadro.length; i++){
    temp[i] = quadro[i];
  }

  // Itera sobre o quadro para decodificar os bits.
  for(int j = 0; j < quadro.length; j++){
    int mask = 1;

    // Enquanto o valor no quadro[j] não for zero, decodifica o bit.
    while(quadro[j] > 0){
      if((quadro[j] & mask) == 0){
        control.mensagemDecodificada.setText('0' + control.mensagemDecodificada.getText());
      } else if((quadro[j] & mask) == 1){
        control.mensagemDecodificada.setText('1' + control.mensagemDecodificada.getText());
      }
      quadro[j] = quadro[j] >> 1; // Desloca o valor 1 bit para a direita.
    }
  }

  return temp; // Retorna o quadro original.
}

 
  public int[] camadaFisicaReceptoraDecodificacaoManchester(int quadro[]){
    int[] conversao = new int[quadro.length/2];
    int indConv = 0;
    int contador = 0;
    control.mensagemDecodificada.setText("");
    String numero = "";

    for(int j = 0; j < quadro.length; j++){

      int mask = 1;

      int vezes = 16;
      
      contador = 0;
      //boolean controle = false;

      if(j % 2 == 0 && j != 0){
        indConv++;
      }//Fim if if if

      while(vezes > 0){
        contador++;
        numero = control.retornaBinario(conversao[indConv]);
        if(contador % 8 == 0){
          if((quadro[j] & mask) == 1){
            quadro[j] = quadro[j] >> 1;
            if((quadro[j] & mask) == 0){
              conversao[indConv] = conversao[indConv] << 1; 
            }//Fim if3
            else{
              conversao[indConv] = conversao[indConv] << 1;
            }//Fim else
          }//Fim if2
          else{
            if((quadro[j] & mask) == 0){
              quadro[j] = quadro[j] >> 1;
              int tempor = quadro[j] >> 1; 
              if((quadro[j] & mask) == 1){
                conversao[indConv] = conversao[indConv] << 2;
                conversao[indConv] = conversao[indConv] | 1; 
              }//Fim if if
              else if((quadro[j] & mask) == 0 && (tempor & mask) == 0 && vezes - 1 > 0){
                break;
              }//Fim else if
              else if(contador == 16 && numero.length() < 30 && quadro[j+1] > 0){
                conversao[indConv] = conversao[indConv] << 1;
              }//Fim else if
            }//Fim if
          }//Fim else
        }//Fim if1
        else{
          if((quadro[j] & mask) == 0){
            quadro[j] = quadro[j] >> 1;
            if((quadro[j] & mask) == 1){
              conversao[indConv] = conversao[indConv] << 1;
              conversao[indConv] = conversao[indConv] | 1; 
            }//Fim if if
            control.mensagemDecodificada.setText('1' + control.mensagemDecodificada.getText());
          }//Fim if
          else if((quadro[j] & mask) == 1){
            quadro[j] = quadro[j] >> 1;
            if((quadro[j] & mask) == 0){
              conversao[indConv] = conversao[indConv] << 1;
              //conversao[indConv] = conversao[indConv] | 0;
              if(contador == 1){
                contador--;
                vezes++;
              }//Fim if 
            }//Fim if if
            control.mensagemDecodificada.setText('0' + control.mensagemDecodificada.getText());
          }//Fim else if
        }//Fim else
        quadro[j] = quadro[j] >> 1;
        vezes--;
      }//Fim while
    }//Fim for j
    return conversao;
  }//Fim metodo camadaFisicaReceptoraDecodificacaoManchester

  public int[] camadaFisicaReceptoraDecodificacaoManchesterDiferencial(int quadro[]) {
    // Cria um array para armazenar os valores decodificados, com metade do tamanho do quadro original
    int[] conversao = new int[quadro.length/2];
    // Variável para rastrear o número de execuções do loop interno
    int execucoes = 0;
    // Variável para rastrear o índice atual em 'conversao'
    int indConv = 0;
    // Máscara para verificar o valor do bit atual
    int mask = 1;

    // Limpa o campo de mensagem decodificada
    control.mensagemDecodificada.setText("");

    // Loop que itera sobre cada elemento do quadro de entrada
    for(int j = 0; j < quadro.length; j++) {
        execucoes = 0;

        // Se o índice atual for par (começando em 0) e não for a primeira iteração
        if(j % 2 == 0 && j != 0) {
            indConv++; // Incrementa o índice para armazenar o próximo byte decodificado
        }

        // Verifica se o bit atual não é igual a zero
        if((quadro[j] & mask) != 0) {
            conversao[indConv] = conversao[indConv] << 1; // Desloca um bit para a esquerda no byte atual
        }

        // Loop interno para processar cada bit do quadro atual
        while(execucoes != 16) {
            execucoes++; // Incrementa o contador de execuções

            // Verifica se o bit atual é igual a um
            if((quadro[j] & mask) == 1) {
                quadro[j] = quadro[j] >> 1; // Desloca um bit para a direita no byte atual

                // Verifica se o próximo bit também é igual a um e atualiza 'conversao' de acordo
                if((quadro[j] & mask) == 1) {
                    conversao[indConv] = conversao[indConv] << 1;
                    conversao[indConv] = conversao[indConv] | 1;
                }
                control.mensagemDecodificada.setText('1' + control.mensagemDecodificada.getText()); // Aqui está a atualização
            } else if((quadro[j] & mask) == 0) {
                quadro[j] = quadro[j] >> 1; // Desloca um bit para a direita no byte atual

                // Verifica se o próximo bit é igual a um e atualiza 'conversao' de acordo
                if((quadro[j] & mask) == 1) {
                    conversao[indConv] = conversao[indConv] << 1;
                }
                control.mensagemDecodificada.setText('0' + control.mensagemDecodificada.getText()); // Aqui está a atualização
            }

            // Desloca um bit para a direita no byte atual
            quadro[j] = quadro[j] >> 1;
        }
    }

    // Retorna o array 'conversao' contendo os bytes decodificados
    return conversao;
}
  public void setControlador(Controlador controle){
    control = controle;
  }//Fim setControlador

}//Fim classe CamadaReceptora