package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;

/*********************************************
Nome: Ana Beatriz Silva e Silva 
Data de inicio: 25/08/2023
data de termino: 05/09/2023
objetivo: Simulando a camada fisica de redes
********************************************/

public class CamadaTransmissora{
  Controlador control;

  public CamadaTransmissora(){
    
  }//Fim metodo construtor CamadaTransmissora

  public void CamadaDeAplicacaoTransmissora(String mensagem){
    int indice = 0;
    // Calcula o tamanho do quadro com base no comprimento da mensagem de entrada
    // Garante que cada quadro tenha até 4 bytes (32 bits)
    if(mensagem.length() % 4 == 0){
      indice = mensagem.length()/4;
    }else{
      indice = ((int)mensagem.length()/4) + 1;
    }//Fim else
    int quadro [] = new int[indice];
    int n = 1;
    int i = 0;
    int aux = 0;
    int v = 0;

    // Itera sobre a mensagem de entrada e converte cada caractere em seu valor ASCII correspondente
    while(i < mensagem.length()){
      aux = mensagem.charAt(i); // Recebe o valor em ASCII da letra
      quadro[v] = (quadro[v] << 8); // Desloca os bits do quadro
      quadro[v] = quadro[v] | aux; // Faz uma operação OR para adicionar o valor ao quadro
      i++;
      if(i != 0 && i % 4 == 0 && v < quadro.length - 1){
        v++;
        // Incrementa o índice do quadro e cria um novo quadro a cada 4 caracteres
      }//Fim if
    }//Fim while  

    // Chama o método CamadaFisicaTransmissora para transmitir o quadro
    CamadaFisicaTransmissora(quadro);
  }//Fim metodo CamadaDeAplicacaoTransmissora


  public void CamadaFisicaTransmissora(int quadro[]) {
    int fluxoBrutoDeBits[];
    
    // Um switch é usado para determinar o tipo de codificação a ser aplicado com base no valor da variável "tipoDeDecodificacao".
    switch (tipoDeDecodificacao) {
        case 0: // Codificação binária
            fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoBinaria(quadro);
            // Chama uma função específica para codificação binária e obtém o fluxo bruto de bits resultante.
            control.meioDeComunicacao(fluxoBrutoDeBits);
            // Chama uma função chamada "meioDeComunicacao" do objeto "control" (que parece ser uma instância de uma classe Controlador) para transmitir o fluxo bruto de bits.
            break;
            
        case 1: // Codificação Manchester
            fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoManchester(quadro);
            // Chama uma função específica para codificação Manchester e obtém o fluxo bruto de bits resultante.
            control.meioDeComunicacao(fluxoBrutoDeBits);
            // Chama uma função chamada "meioDeComunicacao" do objeto "control" para transmitir o fluxo bruto de bits.
            break;
            
        case 2: // Codificação Manchester Diferencial
            fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoManchesterDiferencial(quadro);
            // Chama uma função específica para codificação Manchester Diferencial e obtém o fluxo bruto de bits resultante.
            control.meioDeComunicacao(fluxoBrutoDeBits);
            // Chama uma função chamada "meioDeComunicacao" do objeto "control" para transmitir o fluxo bruto de bits.
            break;
    }//fim do switch/case
  }//fim metodo CamadaFisicaTransmissora


  public int[] CamadaFisicaTransmissoraCodificacaoBinaria(int quadro[]){
    int[] temp = new int[quadro.length]; // Cria um array temporário do mesmo tamanho que o quadro de entrada.

    int mask = 1; // Máscara para verificar cada bit individualmente.

    String formaDeOnda = ""; // Esta variável irá conter a sequência de bits após a codificação.

    // Copia o quadro de entrada para o array temporário 'temp'.
    for(int i = 0; i < quadro.length; i++){
    	temp[i] = quadro[i];
    }//Fim for i

    // Itera sobre cada elemento do quadro.
    for(int j = 0; j < quadro.length; j++){
      while(quadro[j] > 0){
        if((quadro[j] & mask) == 0){
          formaDeOnda = "0" + formaDeOnda; // Se o bit atual for 0, adiciona "0" à sequência.
        }//Fim if
        else if((quadro[j] & mask) == 1){
          formaDeOnda = "1" + formaDeOnda; // Se o bit atual for 1, adiciona "1" à sequência.
        }//Fim else if
        quadro[j] = quadro[j] >> 1; // Move para o próximo bit da direita para a esquerda.
      }//Fim while
    }//Fim for j

    formaDeOnda = "0" + formaDeOnda; // Adiciona um bit "0" no início da sequência (pode ser um bit de start).

    // Chama uma função chamada 'gerarOnda' do objeto 'control' para gerar uma onda com a sequência de bits.
    control.gerarOnda(formaDeOnda);

    return temp; // Retorna o array temporário 'temp'.
  }//fim do metodo CamadaFisicaTransmissoraCodificacaoBinaria


  public int[] CamadaFisicaTransmissoraCodificacaoManchester(int quadro[]){
    int novoTamanho = quadro.length * 2; // O tamanho do novo quadro será o dobro do tamanho do quadro original.
    int[] novoQuadro = new int[novoTamanho]; // Cria um novo array para armazenar o quadro codificado.
    int mask = 1; // Máscara para verificar cada bit individualmente.
    int zeroOUum = 0; // Variavel para armazenar se o bit e 0 ou 1.
    int indiceNQ = 0; // Indice para o novo quadro.
    int cont = 1; // Contador para controlar a inserção de bits de sincronização.
    String formaDeOnda = ""; // Esta variável irá conter a sequência de bits após a codificação.

    // Itera sobre cada elemento do quadro de entrada.
    for(int j = 0; j < quadro.length; j++){
      if(j > 0){
        indiceNQ++;
        cont = 0;
      }//Fim if
      
      while(quadro[j] > 0){
        novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 2; // Desloca 2 bits para a esquerda no novo quadro.

        if((quadro[j] & mask) == 0){
          formaDeOnda = "01" + formaDeOnda; // Se o bit atual for 0, adiciona "01" à sequência (representa 0 em Manchester).
          zeroOUum = 1; // zeroOUum e 1 para representar 0 em Manchester.
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | zeroOUum; // Adiciona zeroOUum ao novo quadro.
          cont++;
        }//Fim if
        else if((quadro[j] & mask) == 1){
          formaDeOnda = "10" + formaDeOnda; // Se o bit atual for 1, adiciona "10" à sequência (representa 1 em Manchester).
          zeroOUum = 2; // zeroOUum é 2 para representar 1 em Manchester.
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | zeroOUum; // Adiciona zeroOUum ao novo quadro.
          cont++;
        }//Fim else if

        quadro[j] = quadro[j] >> 1; // Move para o próximo bit da direita para a esquerda.

        if(cont == 16){
          indiceNQ++;
          // Verifica a necessidade de inserir bits de sincronização.
          String a = control.retornaBinario(quadro[j]);
          if((quadro[j] & mask) == 0 && a.length() > 15){
            quadro[j] = quadro[j] >> 1;
          }//Fim if incluso
          a = control.retornaBinario(quadro[j]);
          cont = 0;
        }//Fim if
      }//Fim while
    }//Fim for j

    formaDeOnda = "01" + formaDeOnda; // Adiciona um bit "01" no início da sequência (pode ser um bit de start).

    // Chama uma função chamada 'gerarOnda' do objeto 'control' para gerar uma onda com a sequência de bits codificados.
    control.gerarOnda(formaDeOnda);

    return novoQuadro; // Retorna o novo quadro codificado.
  }//fim do metodo CamadaFisicaTransmissoraCodificacaoManchester

  
 public int[] CamadaFisicaTransmissoraCodificacaoManchesterDiferencial(int quadro[]){
    //implementacao do algoritmo para CODIFICAR

    int novoTamanho = quadro.length * 2; // O tamanho do novo quadro será o dobro do tamanho do quadro original.
    int[] novoQuadro = new int[novoTamanho]; // Cria um novo array para armazenar o quadro codificado.
    int mask = 1; // Máscara para verificar cada bit individualmente.
    int zeroOUum = 0; // Variável para armazenar se o bit é 0 ou 1.
    int indiceNQ = 0; // Indice para o novo quadro.
    int cont = 1; // Contador para controlar a inserção de bits de sincronização.
    String formaDeOnda = ""; // Esta variável irá conter a sequência de bits após a codificação.

    // Itera sobre cada elemento do quadro de entrada.
    for(int j = 0; j < quadro.length; j++){
      if(j > 0){
        novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
        novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | zeroOUum;
        novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
        indiceNQ++;
        cont = 1;
      }//Fim if
      zeroOUum = 1; // Inicializa zeroOUum como 1.

      while(quadro[j] > 0){
        novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;

        if((quadro[j] & mask) == 0){
          formaDeOnda = "10" + formaDeOnda; // Se o bit atual for 0, adiciona "10" à sequência (Manchester Diferencial para 0).
          zeroOUum = 1; // zeroOUum é 1 para representar 1.
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | zeroOUum;
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
          cont++;
        }//Fim if
        else if((quadro[j] & mask) == 1){
          formaDeOnda = "11" + formaDeOnda; // Se o bit atual for 1, adiciona "11" à sequência (Manchester Diferencial para 1).
          zeroOUum = 1; // zeroOUum é 1 para representar 1.
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | zeroOUum;
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] << 1;
          novoQuadro[indiceNQ] = novoQuadro[indiceNQ] | zeroOUum;
          cont++;
        }//Fim else if

        quadro[j] = quadro[j] >> 1; // Move para o próximo bit da direita para a esquerda.

        if(cont == 17){
          indiceNQ++;
          cont = 1;
        }//Fim if
      }//Fim while
    }//Fim for

    formaDeOnda = "10" + formaDeOnda; // Adiciona um bit "10" no início da sequência (pode ser um bit de start).

    // Chama uma função chamada 'gerarOnda' do objeto 'control' para gerar uma onda com a sequência de bits codificados.
    control.gerarOnda(formaDeOnda);

    return novoQuadro; // Retorna o novo quadro codificado.
  }//fim do metodo CamadaFisicaTransmissoraCodificacaoManchesterDiferencial

  public void setControlador(Controlador controle){
    control = controle;
  }//Fim setControlador
}//Fim classe
