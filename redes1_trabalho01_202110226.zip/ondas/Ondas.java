package ondas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;

/*********************************************
Nome: Ana Beatriz Silva e Silva 
Data de inicio: 25/08/2023
data de termino: 05/09/2023
objetivo: Simulando a camada fisica de redes
********************************************/
public class Ondas extends Thread {
    Controlador control;

    // Construtor da classe Ondas
    public Ondas() {

    }// Fim do método Construtor Ondas

    // Método run que é executado quando a thread é iniciada
    public void run() {
        while (true) {

            // Verifica se a variável de controle "verificacao" no objeto "control" é igual a 1
            if (control.verificacao == 1) {
                control.nivelAlto();
            }// Fim do if
            // Caso contrário, verifica se a variável de controle "verificacao" é igual a 0
            else if (control.verificacao == 0) {
                control.nivelBaixo();
            }// Fim do else if

        }// Fim do while
    }// Fim do método run

    // Método que define a ação quando a onda está alta
    public void ondaAlta() {
        control.nivelBaixo();
    }// Fim do método ondaAlta

    // Método que define a ação quando a onda está baixa
    public void ondaBaixa() {
        control.nivelAlto();
    }// Fim do método ondaBaixa

    // Método para definir o controlador
    public void setControlador(Controlador controle) {
        control = controle;
    }// Fim do método setControlador
}// Fim da classe Ondas
