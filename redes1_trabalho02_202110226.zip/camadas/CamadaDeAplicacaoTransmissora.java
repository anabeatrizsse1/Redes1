package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;

public class CamadaDeAplicacaoTransmissora {
  CamadaEnlaceDadosTransmissora enlaceTransmissora = new CamadaEnlaceDadosTransmissora();
  MetodosBit manipulador = new MetodosBit();

  public void camadaAplicacaoTransmissora(String mensagem) {
    int[] quadro;
    int vetor[] = new int[mensagem.length()];
    for (int i = 0; i < mensagem.length(); i++) {
      vetor[i] = mensagem.charAt(i);
    }
    quadro = manipulador.inteiroEmBits(vetor);
    enlaceTransmissora.CamadaEnlaceDadosTransmissora(quadro);
  }

}