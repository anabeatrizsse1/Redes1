package camadas;
import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static camadas.AplicacaoTransmissora.control;

public class CamadaEnlaceDadosTransmissora{
  // Controlador control;
  CamadaFisicaTransmissora camadaFisTransmissora = new CamadaFisicaTransmissora();
  MetodosBit manipulador = new MetodosBit();

  public CamadaEnlaceDadosTransmissora(){
  
  }//Fim metodo construtor
  
  public void CamadaEnlaceDadosTransmissora(int quadro[]){
    CamadaEnlaceDadosTransmissoraEnquadramento(quadro); 
    //CamadaDeEnlaceDadosTransmissoraControleDeErro(quadro);
    //CamadaDeEnlaceDadosTransmissoraControleDeFluxo(quadro);
  }//fim metodo CamadaEnlanceDadosTransmissora
  
  public void CamadaEnlaceDadosTransmissoraEnquadramento(int quadro[]){
    int tipoDeEnquadramento = control.tipoDeEnquadramento;
    int quadroEnquadrado [];
    switch (tipoDeEnquadramento) {
      case 0 : //contagem de caracteres
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres(quadro);
        camadaFisTransmissora.CamadaFisicaTransmissora(quadroEnquadrado);
        break;
      case 1 : //insercao de bytes
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBytes(quadro);
        camadaFisTransmissora.CamadaFisicaTransmissora(quadroEnquadrado);
        break;
      case 2 : //insercao de bits
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBits(quadro);
        camadaFisTransmissora.CamadaFisicaTransmissora(quadroEnquadrado);
        break;
      case 3 : //violacao da camada fisica
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoViolacaoDaCamadaFisica(quadro);
        camadaFisTransmissora.CamadaFisicaTransmissora(quadroEnquadrado);
        break;
    }//fim do switch/case
  }//fim do metodo CamadaEnlaceTransmissoraEnquadramento

  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres(int quadro []){
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    int [] informacaoDeControle = new int[quadro.length];

    for(int i = 0; i < quadro.length; i++){
      informacaoDeControle[i] = (manipulador.retornaBitsSignificativos(quadro[i]))/8;
      acumulador += informacaoDeControle[i];
      // System.out.println("informacao: ");
      // System.out.println(informacaoDeControle[i]);
    }//Fim for

    // System.out.println();

    // System.out.println("valor acumulado: " + acumulador);

    if(acumulador > 3){
      while(acumulador > 3){
        acumulador -= 3;
        qtdIndices++;
      }//Fim while
      qtdIndices += 1;
    }else{
      qtdIndices = 1;
    }//Fim else

    int[] novoQuadro = new int[qtdIndices];

     // System.out.println("quantidade de indicies: " + qtdIndices);
     // System.out.println("valor do ultimo quadro: " + acumulador);

    // System.out.println("---------------");

    //quadro = manipulador.moverParaEsquerda(quadro);

    for(int m = 0; m < quadro.length; m++){
      quadro[m] = manipulador.moverBitsEsquerda(quadro[m]);
      // manipulador.(quadro[m]);
    }// fim for

    // System.out.println("---------------");

    // System.out.println("");
    // System.out.println("NO ENLACE TRANSMISSOR: ");
    // System.out.println("");

    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      while(cont < 32){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        inteiro <<= 1;
        cont++;
        cont2++;
        if(cont2 % 24 == 0 && cont2 != 0){

          // System.out.println("quadro que entrou(24): " + manipulador.(novoInteiro));

          //49 em decimal referencia 1 em ascll
          //50 em decimal referencia 2 em ascll
          //51 em decimal referencia 3 em ascll
          if(indiceNvQ == novoQuadro.length - 1){
            if(acumulador == 1){
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 49; //adicionando informacao de controle 1
            }else if(acumulador == 2){
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 50; //adicionando informacao de controle 2 
            }else if(acumulador == 3){
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 51; //adicionando informacao de controle 3
            }//Fim else if
          }else{
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 51; //adicionando informacao de controle 3
          }//Fim else

          int contador = 0;
          
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          while(contador < 24){
            bit = (novoInteiro & mask) == 0 ? 0 : 1;
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            // System.out.println("ultimo quadro codificado break");
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
          // System.out.println("VALOR DO CONT: " + cont);
        }//Fim if
        if(cont == 32 && j == quadro.length - 1 && novoInteiro != 0){
          int contador = 0;
          if(acumulador == 1){
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 49; //adicionando informacao de controle 1
          }else if(acumulador == 2){
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 50; //adicionando informacao de controle 2 
          }else if(acumulador == 3){
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 51; //adicionando informacao de controle 3
          }//Fim else if
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          while(contador < (acumulador * 8)){
            bit = (novoInteiro & mask) == 0 ? 0 : 1;
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while
          if(acumulador * 8 == 8){
            novoQuadro[indiceNvQ] <<= 16;
          }else if(acumulador * 8 == 16){
            novoQuadro[indiceNvQ] <<= 8;
          }//Fim else if
        }//Fim if
      }//Fim while
    }//Fim for
   return novoQuadro;
  }//Fim metodo CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres

  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBytes (int quadro []) {
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    //se achar o byte de flag dentro da mensagem adiciona um escape
    //se achar o byte de escape dentro da mensagem adiciona outro escape
    // byte de flag = a
    // byte de escape = esc

    int [] informacaoDeControle = new int[quadro.length];

    for(int i = 0; i < quadro.length; i++){
      informacaoDeControle[i] = (manipulador.retornaBitsSignificativos(quadro[i]))/8;
      acumulador += informacaoDeControle[i];
      // System.out.println("informacao: ");
      // System.out.println(informacaoDeControle[i]);
    }//Fim for

    // System.out.println("valor acumulado: " + acumulador);

    if(acumulador > 2){
      while(acumulador > 2){
        acumulador -= 2;
        qtdIndices++;
      }//Fim while
      qtdIndices += 1;
    }else{
      qtdIndices = 1;
    }//Fim else

    int[] novoQuadro = new int[qtdIndices];

     // System.out.println("quantidade de indicies: " + qtdIndices);
     // System.out.println("valor do ultimo quadro: " + acumulador);

    for(int m = 0; m < quadro.length; m++){
      quadro[m] = manipulador.moverBitsEsquerda(quadro[m]);
    }// fim for

    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      while(cont < 32){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        inteiro <<= 1;
        cont++;
        cont2++;
        if(cont2 % 16 == 0 && cont2 != 0){

          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 31;

          int contador = 0;
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          while(contador < 16){
            bit = (novoInteiro & mask) == 0 ? 0 : 1;
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while
          int flag = 31;
          contador = 0;
          flag = manipulador.moverBitsEsquerda(flag);
          while(contador < 8){
            bit = (flag & mask) == 0 ? 0 : 1;
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
          }//Fim while


          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            // System.out.println("ultimo quadro codificado break");
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
        }//Fim else if
        if(cont == 32 && j == quadro.length - 1 && novoInteiro != 0){
          int contador = 0;
          
          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 31; // inserindo bit de flag no começo

          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          while(contador < (acumulador * 8)){
            bit = (novoInteiro & mask) == 0 ? 0 : 1;
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while

          int flag = 31;
          contador = 0;
          flag = manipulador.moverBitsEsquerda(flag);
          while(contador < 8){
            bit = (flag & mask) == 0 ? 0 : 1;
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
          }//Fim while

          if(acumulador * 8 == 8){
            novoQuadro[indiceNvQ] <<= 8;
          }//Fim if
        }//Fim if
      }//Fim while
    }//Fim for

    return novoQuadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBytes
  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBits (int quadro []) {
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    //se achar o byte de flag dentro da mensagem adiciona um escape
    //se achar o byte de escape dentro da mensagem adiciona outro escape
    // byte de flag = a
    // byte de escape = esc

    int [] informacaoDeControle = new int[quadro.length];

    for(int i = 0; i < quadro.length; i++){
      informacaoDeControle[i] = (manipulador.retornaBitsSignificativos(quadro[i]))/8;
      acumulador += informacaoDeControle[i];
    }//Fim for

    qtdIndices = acumulador;

    int[] novoQuadro = new int[acumulador];

     // System.out.println("quantidade de indicies: " + qtdIndices);
     // System.out.println("valor do ultimo quadro: " + acumulador);


    for(int m = 0; m < quadro.length; m++){
      quadro[m] = manipulador.moverBitsEsquerda(quadro[m]);
    }// fim for

    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      while(cont < 32){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        inteiro <<= 1;
        cont++;
        cont2++;
        if(cont2 % 8 == 0 && cont2 != 0){
          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 126;
          int contador = 0;
          
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          int contaUm = 0;

          if(manipulador.verificaCincoBitsSequenciais(novoInteiro,1) == true){
            novoQuadro[indiceNvQ] <<= 7;
            while(contador < 8){
              bit = (novoInteiro & mask) == 0 ? 0 : 1;
              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              contador++;
              if(bit == 1){
                contaUm++;
                if(contaUm == 5){
                  novoQuadro[indiceNvQ] <<= 1;
                  novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 0;
                  contaUm = 0;
                }//Fim if
              }//Fim if
            }//Fim while
          }else{
            while(contador < 8){
              bit = (novoInteiro & mask) == 0 ? 0 : 1;
              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              contador++;
            }//Fim while
          }//fim else

          int flag = 126;
          contador = 0;
          flag = manipulador.moverBitsEsquerda(flag);
          while(contador < 8){
            bit = (flag & mask) == 0 ? 0 : 1;
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
          }//Fim while

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            System.out.println("ultimo quadro codificado break");
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
        }//Fim if
        if(cont == 32 && j == quadro.length - 1 && novoInteiro != 0){
          int contador = 0;
          
          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 126; // inserindo bit de flag no começo
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);
          // System.out.println("Valor do novo inteiro: ");
          // manipulador.(novoInteiro);

          int contaUm = 0;

          if(manipulador.verificaCincoBitsSequenciais(novoInteiro,1) == true){
            novoQuadro[indiceNvQ] <<= 7;
            while(contador < 8){
              bit = (novoInteiro & mask) == 0 ? 0 : 1;;
              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              
              contador++;
              if(bit == 1){
                contaUm++;
                if(contaUm == 5){
                  novoQuadro[indiceNvQ] <<= 1;
                  novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 0;
                  contaUm = 0;
                }//Fim if
              }//Fim if
            }//Fim while
          }else{
            while(contador < 8){
              bit = (novoInteiro & mask) == 0 ? 0 : 1;
              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              contador++;
            }//Fim while
          }//fim else

          int flag = 126;
          contador = 0;
          flag = manipulador.moverBitsEsquerda(flag);
          while(contador < 8){
            bit = (flag & mask) == 0 ? 0 : 1;
            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
          }//Fim while
          
          novoQuadro[indiceNvQ] <<= 8;
        }//Fim if
      }//Fim while
    }//Fim for

    for(int i =0; i < novoQuadro.length; i++){
      novoQuadro[i] = manipulador.moverBitsEsquerda(novoQuadro[i]);
    }//FIm for

    return novoQuadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraInsercaoDeBits
  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoViolacaoDaCamadaFisica(int quadro []) {

    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    int [] informacaoDeControle = new int[quadro.length];

    for(int i = 0; i < quadro.length; i++){
      informacaoDeControle[i] = (manipulador.retornaBitsSignificativos(quadro[i]))/8;
      acumulador += informacaoDeControle[i];
    }//Fim for

    qtdIndices = acumulador;

    int[] novoQuadro = new int[acumulador];

    for(int m = 0; m < quadro.length; m++){
      quadro[m] = manipulador.moverBitsEsquerda(quadro[m]);
    }// fim for

    for(int j = 0; j < quadro.length; j++){
      cont = 0;
      inteiro = quadro[j];
      while(cont < 32){
        bit = (inteiro & mask) == 0 ? 0 : 1;
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        inteiro <<= 1;
        cont++;
        cont2++;
        if(cont2 % 8 == 0 && cont2 != 0){
          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 3; //adiciona 11 para limitar o inicio do quadro
          int contador = 0;
          
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          int contaUm = 0;

          novoQuadro[indiceNvQ] <<= 6;

          while(contador < 8){
            bit = (novoInteiro & mask) == 0 ? 1 : 2;
            novoQuadro[indiceNvQ] <<= 2;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while

          novoQuadro[indiceNvQ] <<= 8;

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
        }//Fim if
        if(cont == 32 && j == quadro.length - 1 && novoInteiro != 0){
          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 3;
          int contador = 0;
        
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          int contaUm = 0;

          novoQuadro[indiceNvQ] <<= 8;

          while(contador < 8){
            bit = (novoInteiro & mask) == 0 ? 1 : 2;
            novoQuadro[indiceNvQ] <<= 2;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }//Fim while

          novoQuadro[indiceNvQ] <<= 8;

          if(indiceNvQ < qtdIndices - 1){
            // System.out.println("ENTREI E SUBI O INDICE");
            indiceNvQ += 1;
          }else{
            break;
          }//Fim else
          novoInteiro = 0;
          cont2 = 0;
        }//Fim if
      }//Fim while
    }//Fim for

    for(int i =0; i < novoQuadro.length; i++){
      novoQuadro[i] = manipulador.moverBitsEsquerda(novoQuadro[i]);
    }//FIm for
    return novoQuadro;
  }//fim do metodo CamadaEnlaceDadosTransmissoraViolacaoDaCamadaFisica
}//fim classe CamadaEnlaceDadosTransmissora