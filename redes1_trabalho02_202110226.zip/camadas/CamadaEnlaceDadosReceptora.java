package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static camadas.AplicacaoTransmissora.control;

public class CamadaEnlaceDadosReceptora {
  CamadaDeAplicacaoReceptora camadaApliReceptora = new CamadaDeAplicacaoReceptora();
  MetodosBit manipulador = new MetodosBit();

  public CamadaEnlaceDadosReceptora() {

  }

  public void CamadaEnlaceDadosReceptora(int quadro[]) {
    CamadaEnlaceDadosReceptoraEnquadramento(quadro);

  }

  public void CamadaEnlaceDadosReceptoraEnquadramento(int quadro[]) {
    int tipoDeEnquadramento = control.tipoDeEnquadramento;
    int[] quadroEnquadrado;
    switch (tipoDeEnquadramento) {
      case 0:
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(quadro);
        camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);
        break;
      case 1:
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes(quadro);
        camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);
        break;
      case 2:
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits(quadro);
        camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);
        break;
      case 3:
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoDaCamadaFisica(quadro);
        camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);
        break;
    }
  }

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(int quadro[]) {
    for (int j = 0; j < quadro.length; j++) {
      quadro[j] <<= 8;
    }
    return quadro;
  }

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes(int quadro[]) {
    for (int j = 0; j < quadro.length; j++) {
      quadro[j] >>= 8;
      quadro[j] <<= 16;
    }

    return quadro;
  }

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits(int quadro[]) {
    int mask = 1;
    int bit = 0;
    int bit2 = 0;
    int bit3 = 0;
    int bitUm = 0;
    int inteiro = 0;
    int umBitaFrente = 0;
    int umBitaFrente2 = 0;

    for (int j = 0; j < quadro.length; j++) {
      quadro[j] <<= 8;
      if (manipulador.retornaPrimeiroByte2(quadro[j]) == 0) {
        quadro[j] >>= 16;
        inteiro = quadro[j];
        umBitaFrente = inteiro >> 1;
        umBitaFrente2 = umBitaFrente >> 1;
        while (true) {
          bit = (inteiro & mask) == 0 ? 0 : 1;
          bit2 = (umBitaFrente & mask) == 0 ? 0 : 1;
          bit3 = (umBitaFrente2 & mask) == 0 ? 0 : 1;
          if (bit == 0 && bit2 == 0 && bit3 == 1) {
            inteiro >>= 1;
            quadro[j] = inteiro;
            break;
          } else {
            inteiro >>= 1;
            umBitaFrente >>= 1;
            umBitaFrente2 >>= 2;
          }
        }
      } else {
        quadro[j] >>= 24;
      }
    }
    for (int i = 0; i < quadro.length; i++) {
      quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
    }

    return quadro;
  }

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoDaCamadaFisica(int quadro []) {
    int[] novoQuadro = new int [quadro.length];
    int contador = 0;
    int bit = 0;
    int mask = 1 << 31;

    for(int j = 0; j < quadro.length; j++){
      contador = 0;
      quadro[j] <<= 8;
      while(contador < 8){
        bit = (quadro[j] & mask) == 0 ? 0 : 1;
        novoQuadro[j] <<= 1;
        novoQuadro[j] = novoQuadro[j] | bit;
        quadro[j] <<= 2;
        contador++;
      }
    }
    for(int i =0; i < quadro.length; i++){
      novoQuadro[i] = manipulador.moverBitsEsquerda(novoQuadro[i]);
    }
    return novoQuadro;
  }
}