package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static camadas.AplicacaoTransmissora.control;

public class MeioDeComunicacao {

  CamadaFisicaReceptora camadaFisReceptora = new CamadaFisicaReceptora();

  String formaDeOnda = "";

  public void meioDeComunicacao(int fluxoBrutoDeBits[]) {
    int[] fluxoBrutoDeBitsPontoA, fluxoBrutoDeBitsPontoB;

    MetodosBit manipulador = new MetodosBit();

    fluxoBrutoDeBitsPontoA = fluxoBrutoDeBits;
    fluxoBrutoDeBitsPontoB = new int[fluxoBrutoDeBitsPontoA.length];

    int mask = 1 << 31;
    int bit = 0;
    int temporarioA = 0;
    int temporarioB = 0;
    int cont = 0;
    for (int j = 0; j < fluxoBrutoDeBitsPontoA.length; j++) {
      cont = 0;
      temporarioA = fluxoBrutoDeBitsPontoA[j];
      while (cont < 32) {
        bit = (temporarioA & mask) == 0 ? 0 : 1;
        temporarioB <<= 1;
        temporarioB = temporarioB | bit;
        temporarioA <<= 1;
        cont++;
        formaDeOnda += (bit + "");
      }
      fluxoBrutoDeBitsPontoB[j] = temporarioB;
      temporarioB = 0;
    }
    control.gerarOnda(formaDeOnda);
    camadaFisReceptora.camadaFisicaReceptora(fluxoBrutoDeBitsPontoB);
  }
}