package controlador;

import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Line;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.ScrollPane;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.scene.control.ChoiceBox;
import camadas.*;

/* ***************************************************************
* Autor: Ana Beatriz Silva e Silva 
* Matricula: 202110226
* Inicio: 10/10/2023
* Ultima alteracao: 15/10/2023
* Nome: Camada de Enlace de Dados - subcamada LLC - Enquadramento
* Funcao: Simular os algoritmos de enquadramento 
*************************************************************** */


public class Controlador implements Initializable {
  AplicacaoTransmissora aplicacaoTransmissora;
  CamadaDeAplicacaoReceptora camadAplicacaoReceptora;

  int x = 0;

  public int largura = 0;
  public int largura2 = 0;

  public int verificacao = 30;

  @FXML
  public TextField mensagem;
  @FXML
  public TextField mensagemDecodificada;
  @FXML
  public TextField mensagemRecebida;
  @FXML
  public TextField mensagemRecebidaTela;
  @FXML
  public AnchorPane anchor;
  @FXML
  public ScrollPane scroll;
  @FXML
  private ChoiceBox codificacao;
  @FXML
  private ChoiceBox enquadramento;
  private String mensagemCopiada;

  public static int tipoDeEnquadramento = 0;

  public static int tipoDeDecodificacao = 0;

  @FXML
  private ImageView nivelBaixo;
  @FXML
  private ImageView nivelAlto;

  ObservableList<String> lstcodificacao = FXCollections.observableArrayList("Binaria", "Manchester",
      "Manchester Diferencial");
  ObservableList<String> lstenquadramento = FXCollections.observableArrayList("Contagem de caracteres",
      "Insercao de Bytes", "Insercao de Bits", "Violacao da camada fisica");

  public Controlador() {
    aplicacaoTransmissora = new AplicacaoTransmissora();
    camadAplicacaoReceptora = new CamadaDeAplicacaoReceptora();

    aplicacaoTransmissora.setControlador(this);
    camadAplicacaoReceptora.setControlador(this);
  }

  @FXML
  public void enviar(ActionEvent event) {
    if ((enquadramento.getValue() + "") == "Contagem de caracteres") {
      tipoDeEnquadramento = 0;
    } else if ((enquadramento.getValue() + "") == "Insercao de Bytes") {
      tipoDeEnquadramento = 1;
    } else if ((enquadramento.getValue() + "") == "Insercao de Bits") {
      tipoDeEnquadramento = 2;
    } else {
      tipoDeEnquadramento = 3;
    } 
    if (codificacao.getValue() == "Binaria") {
      tipoDeDecodificacao = 0;
    } else if (codificacao.getValue() == "Manchester") {
      tipoDeDecodificacao = 1;
    } else {
      tipoDeDecodificacao = 2;
    } 
    aplicacaoTransmissora.aplicacaoTransmissora(mensagem.getText());
  }

  public void ondaBaixa() {
    if (largura2 > 0) {
      Line line = new Line();
      line.setStartX(0.0f);
      line.setStartY(80.0f);
      line.setEndX(0.0f); 
      line.setEndY(100.0f);
      line.setLayoutX(0);
      line.setLayoutY(510);

      Line line2 = new Line();
      line2.setStartX(80.0f);
      line2.setStartY(0.0f);
      line2.setEndX(100.0f);
      line2.setEndY(0.0f);
      line2.setLayoutX(-79);
      line2.setLayoutY(610);

      x += 21;

      line.setLayoutX((line.getLayoutX()) + x);
      line2.setLayoutX((line.getLayoutX()) - 79);
      anchor.getChildren().add(line);
      anchor.getChildren().add(line2);
    } else if (largura2 == 0) {
      Line line2 = new Line();
      line2.setStartX(80.0f);
      line2.setStartY(0.0f);
      line2.setEndX(100.0f); 
      line2.setEndY(0.0f);
      line2.setLayoutX(-79);
      line2.setLayoutY(610);

      x += 21;

      line2.setLayoutX((line2.getLayoutX()) + x);
      anchor.getChildren().add(line2);
    } 
  }

  public void ondaAlta() {
    if (largura > 0) {
      Line line = new Line();
      line.setStartX(0.0f);
      line.setStartY(80.0f);
      line.setEndX(0.0f); 
      line.setEndY(100.0f);
      line.setLayoutX(0);
      line.setLayoutY(510);

      Line line2 = new Line();
      line2.setStartX(80.0f);
      line2.setStartY(0.0f);
      line2.setEndX(100.0f); 
      line2.setEndY(0.0f);
      line2.setLayoutX(-80);
      line2.setLayoutY(589);
      x += 21;

      line.setLayoutX((line.getLayoutX()) + x);
      line2.setLayoutX((line.getLayoutX()) - 80);
      anchor.getChildren().add(line);
      anchor.getChildren().add(line2);
     
    } else if (largura == 0) {
      Line line2 = new Line();
      line2.setStartX(80.0f);
      line2.setStartY(0.0f);
      line2.setEndX(100.0f); 
      line2.setEndY(0.0f);
      line2.setLayoutX(-80);
      line2.setLayoutY(589);
      x += 21;
      line2.setLayoutX((line2.getLayoutX()) + x);

      anchor.getChildren().add(line2);
    } 
  }

  public void gerarOnda(String formaDeOnda) {
    for (int i = 0; i < formaDeOnda.length(); i++) {
      if (formaDeOnda.charAt(i) == '0') {
        largura += 1;
        ondaBaixa();
        largura2 = 0;
      } else if (formaDeOnda.charAt(i) == '1') {
        largura2 += 1;
        ondaAlta();
        largura = 0;
      } 
    } 
  }

  public String retornaBinario(int inteiro) {
    String stringb = "";
    while (inteiro >= 1) {
      if (inteiro % 2 == 0) {
        stringb += "0";
      } else {
        stringb += "1";
      }
      inteiro = inteiro / 2;
    } 
    System.out.println(stringb);
    return stringb;
  }

  @Override
  public void initialize(URL url, ResourceBundle rb) {
    codificacao.setValue("Binaria");
    enquadramento.setValue("Contagem de caracteres");
    codificacao.setItems(lstcodificacao);
    enquadramento.setItems(lstenquadramento);
  }
}