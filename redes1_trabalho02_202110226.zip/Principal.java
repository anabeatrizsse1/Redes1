import controlador.Controlador;
import camadas.*;
import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/* ***************************************************************
* Autor: Ana Beatriz Silva e Silva 
* Matricula: 202110226
* Inicio: 10/10/2023
* Ultima alteracao: 15/10/2023
* Nome: Camada de Enlace de Dados - subcamada LLC - Enquadramento
* Funcao: Simular os algoritmos de enquadramento 
*************************************************************** */


public class Principal extends Application{

	public static Scene aplicacao;

  @Override
  public void start(Stage primaryStage) throws IOException {
    Parent fxmlAplicacao = FXMLLoader.load(getClass().getResource("/tela/Tela.fxml"));
    aplicacao = new Scene(fxmlAplicacao);
    primaryStage.setScene(aplicacao);
    primaryStage.show();
  }//Fim metodo start

  public static void main(String args[]){
    launch(args);
  }//Fim main

}//Fim classe Principal