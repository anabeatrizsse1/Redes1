import controlador.Controlador;
import camadas.*;
import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import controlador.Controlador;

/* ***************************************************************
* Autor: Ana Beatriz Silva e Silva 
* Matricula: 202110226
* Inicio: 01/11/2023
* Ultima alteracao: 05/11/2023
* Nome: Controle de Erros
* Funcao: Simular os algoritmos de controle de erros 
*************************************************************** */

public class Principal extends Application {

  public static Parent root;
  public static Stage stage = new Stage();

  @Override
  public void start(Stage stage) throws Exception {
    root = FXMLLoader.load(getClass().getResource("/tela/Tela.fxml"));
    Scene scene = new Scene(root);
    Principal.stage.setTitle("ZapMuuh");
    Principal.stage.getIcons().add(new Image("/imagens/vaquinha.png"));
    Principal.stage.setScene(scene);
    Principal.stage.setResizable(false);
    Principal.stage.sizeToScene();
    Principal.stage.centerOnScreen();
    Principal.stage.show();
  }

  public static void main(String[] args) {
    launch(args);
  }

}
