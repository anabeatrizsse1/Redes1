package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static camadas.AplicacaoTransmissora.control;

public class AplicacaoReceptora{

  public void aplicacaoReceptora( String mensagem){
   	if(control.host == "host1"){
      String mensagemConcatenada = control.mensagemRecebida2.getText() + mensagem;
      
      control.mensagemRecebida2.setText(mensagemConcatenada);
    }else if(control.host == "host2"){
      String mensagemConcatenada = control.mensagemRecebida.getText() + mensagem;
    
      control.mensagemRecebida.setText(mensagemConcatenada);
    }
  }
}