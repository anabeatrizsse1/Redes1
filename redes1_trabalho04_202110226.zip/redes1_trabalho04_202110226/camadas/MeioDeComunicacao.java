package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import java.util.Random;
import static camadas.AplicacaoTransmissora.control;

public class MeioDeComunicacao{
	
  public static Object semaforo_quadro;
public static Object semaforo_fluxo;
public static Semaphore semaforo;
  CamadaFisicaReceptora camadaFisReceptora = new CamadaFisicaReceptora();
  String formaDeOnda = "";

  public void meioDeComunicacao(int fluxoBrutoDeBits []){
    int[] fluxoBrutoDeBitsPontoA, fluxoBrutoDeBitsPontoB;
    Random gerador = new Random();

    MetodosBit manipulador = new MetodosBit();

    
    
    fluxoBrutoDeBitsPontoA = fluxoBrutoDeBits;
    fluxoBrutoDeBitsPontoB = new int[fluxoBrutoDeBitsPontoA.length];

    int mask = 1 << 31;
    int bit = 0;
    int temporarioA = 0;
    int temporarioB = 0;
    int cont = 0;
    //int qtdBits = 0;
    int x1 = 0;
    int x2 = 0;
    int valor = 0;
    boolean alteracao = false;
     // numero entre 1 e 4 25 numero           numero entre 3 e 4 50              numero entre  4 e 4 100
    if((int)(control.probabilidadeErro.getValue()) == 0){
      x1 = 0;
      x2 = 0;
    }
    else if((int)(control.probabilidadeErro.getValue()) > 0 && (int)(control.probabilidadeErro.getValue()) < 26){
      //25 por cento
      x1 = 0;
      x2 = 4;
      valor = 2;
    }else if((int)(control.probabilidadeErro.getValue()) > 25 && (int)(control.probabilidadeErro.getValue()) < 76){
      //50 e 75 por cento
      x1 = 0;
      x2 = 2;
      valor = 1;
    }//fim else
    else if((int)(control.probabilidadeErro.getValue()) == 100){
      x1 = 100;
      x2 = 100;
    }//fim else

    for(int j = 0; j < fluxoBrutoDeBitsPontoA.length; j++){
    	cont = 0;
    	temporarioA = fluxoBrutoDeBitsPontoA[j];
	    while(cont < 32){
        //erro em rajada ocorrendo na mensagem
	    	bit = (temporarioA & mask) == 0 ? 0 : 1;
        if(cont >= 8 && cont <=15){
          if(x1 == 100 && x2 == 100 && alteracao == false){
            alteracao = true;
            //inverte bit na posicao 100 por cento
            if(bit == 0){
              bit = 1;
            }else if(bit == 1){
              bit = 0;
            }//fim else if
          }else if(x1 == 0 && x2 == 0){
            //nao emite erros 0 por cento
          }else if(gerador.nextInt(x2) == valor && alteracao == false){
            //inverte bit na posicao 25 50 e 75 por cento
            if(bit == 0){
              bit = 1;
            }else if(bit == 1){
              bit = 0;
            }//fim else if
          }//fim else if
	    	}//fim if
        temporarioB <<= 1;
	    	temporarioB = temporarioB | bit;
	    	temporarioA <<= 1;
	    	cont++;
	    	formaDeOnda += (bit + "");
	    }//Fim while incluso
	    fluxoBrutoDeBitsPontoB[j] = temporarioB;
	    temporarioB = 0;
	  }//Fim for

    control.gerarOnda(formaDeOnda);
    camadaFisReceptora.camadaFisicaReceptora(fluxoBrutoDeBitsPontoB);
  }//Fim metodo meioDeComunicacao
}//Fim classe MeioDeComunicacao