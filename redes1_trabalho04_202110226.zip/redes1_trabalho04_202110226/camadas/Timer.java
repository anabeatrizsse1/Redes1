package camadas;

import static camadas.CamadaEnlaceDadosTransmissora.verificaAck;
import static camadas.CamadaEnlaceDadosTransmissora.stopAndWait;
import static camadas.CamadaEnlaceDadosReceptora.stopAndWait2;
public class Timer extends Thread{
	int contador = 0;
	String host;
	public Timer(String host){
		this.host = host;
	}

	public void run(){
		try{
			sleep(150);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		if(host == "host1"){
			stopAndWait.release();
		}else if(host == "host2"){
			stopAndWait2.release();
		}//fim else if
	}//fim run
}//fim classe Timer