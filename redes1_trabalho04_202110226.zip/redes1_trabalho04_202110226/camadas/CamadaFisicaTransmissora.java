package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;

public class CamadaFisicaTransmissora {

    MeioDeComunicacao meio = new MeioDeComunicacao();
    MetodosBit manipulador = new MetodosBit();
	public void CamadaFisicaTransmissora(int quadro[]) {
		int fluxoBrutoDeBits[];
		switch (tipoDeDecodificacao) {
			case 0:
				fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoBinaria(quadro);
				meio.meioDeComunicacao(fluxoBrutoDeBits);
				break;
			case 1:
				fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoManchester(quadro);
				meio.meioDeComunicacao(fluxoBrutoDeBits);
				break;
			case 2: 
				fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoManchesterDiferencial(quadro);
				meio.meioDeComunicacao(fluxoBrutoDeBits);
				break;
		}
	}

	private int[] CamadaFisicaTransmissoraCodificacaoBinaria(int quadro[]) {

		return quadro;
	}
	public void binariaDireta(int quadro[]){
		int fluxoBrutoDeBits[];
		fluxoBrutoDeBits = CamadaFisicaTransmissoraCodificacaoBinaria(quadro);
		meio.meioDeComunicacao(fluxoBrutoDeBits);
	  }
	

	private int[] CamadaFisicaTransmissoraCodificacaoManchester(int quadro[]) {
		int[] novoQuadro = new int[quadro.length * 2];
		int mask = 1 << 31;
		int inteiro = 0;
		int cont = 0;
		int bit = 0;
		int inteiroManchester = 0;
		int indiceManch = 0;
		int umBitaFrente = 0;
		for (int j = 0; j < quadro.length; j++) {
			cont = 0;
			inteiro = quadro[j];
			umBitaFrente = inteiro;
			umBitaFrente <<= 1;

			while (cont < 32) {
				bit = (inteiro & mask) == 0 ? 1 : 2;
				inteiroManchester <<= 2;
				inteiroManchester = inteiroManchester | bit;
				inteiro <<= 1;
				cont++;
				if (cont % 16 == 0 && cont != 0) {
					novoQuadro[indiceManch] = inteiroManchester;
					if (indiceManch < (quadro.length * 2) - 1) {
						indiceManch += 1;
					}
					inteiroManchester = 0;
				}
			}
		}
		return novoQuadro;
	}

	private int[] CamadaFisicaTransmissoraCodificacaoManchesterDiferencial(int quadro[]) {
		int[] novoQuadro = new int[quadro.length * 2];
		int mask = 1 << 31;
		int inteiro = 0;
		int cont = 0;
		int bit = 0;
		int inteiroManchesterDif = 0;
		int indiceManch = 0;
		int umBitaFrente = 0;

		for (int j = 0; j < quadro.length; j++) {
			cont = 0;
			inteiro = quadro[j];
			umBitaFrente = inteiro;
			umBitaFrente <<= 1;

			while (cont < 32) {
				bit = (inteiro & mask) == 0 ? 1 : 3;
				inteiroManchesterDif <<= 2;
				inteiroManchesterDif = inteiroManchesterDif | bit;
				inteiro <<= 1;
				cont++;
				if (cont % 16 == 0 && cont != 0) {
					novoQuadro[indiceManch] = inteiroManchesterDif;
					if (indiceManch < (quadro.length * 2) - 1) {
						indiceManch += 1;
					}
					inteiroManchesterDif = 0;
				}
			}
		}
		return novoQuadro;
	}

}