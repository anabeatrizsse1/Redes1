package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static controlador.Controlador.tipoDeDecodificacao;
import static camadas.CamadaFisicaReceptora.*;


public class CamadaDeAplicacaoTransmissora {
  private CamadaEnlaceDadosTransmissora enlaceReceptora;
  private CamadaEnlaceDadosTransmissora enlaceTransmissora;
  private MetodosBit manipulador;

  public CamadaDeAplicacaoTransmissora() {
    // Inicialize as instâncias no construtor ou em um método de inicialização
    enlaceReceptora = new CamadaEnlaceDadosTransmissora();
    enlaceTransmissora = new CamadaEnlaceDadosTransmissora();
    manipulador = new MetodosBit();
  }

  public void camadaAplicacaoTransmissora(String mensagem, String host) {
    int[] quadro;
    int vetor[] = new int[mensagem.length()];
    for (int i = 0; i < mensagem.length(); i++) {
      vetor[i] = mensagem.charAt(i);
    }
    quadro = manipulador.inteiroEmBits(vetor);

    if (host.equals("host1")) {
      enlaceTransmissora.CamadaEnlaceDadosTransmissora(quadro);
    } else if (host.equals("host2")) {
      enlaceReceptora.CamadaEnlaceDadosTransmissora(quadro);
    }
  }
}
