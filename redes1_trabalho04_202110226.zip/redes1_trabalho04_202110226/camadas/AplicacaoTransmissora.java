package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;

import static camadas.CamadaEnlaceDadosTransmissora.enlaceTransmissora;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;

public class AplicacaoTransmissora{
  public static Controlador control;
  CamadaDeAplicacaoTransmissora camadaTransmissora = new CamadaDeAplicacaoTransmissora();

  public void aplicacaoTransmissora(String mensagem, String host){
    enlaceTransmissora.contaErros =0;
    camadaTransmissora.camadaAplicacaoTransmissora(mensagem, host);
  } 

  public void setControlador(Controlador controlador){
    control = controlador;
  }
}