package camadas;

public class Vetor {

  public static int[] cortaVetor(int[] vetor, int tamanho) {
    int[] saida = new int[tamanho];
    for (int i = 0; i < tamanho; i++)
      saida[i] = vetor[i];
    return saida;
  } 
  public static int[] copiaVetor(int[] vetor, int indice) {
    int[] saida = new int[vetor.length - indice];
    for (int i = 0; (i + indice) < vetor.length; i++)
      saida[i] = vetor[i + indice];
    return saida;
  } 
  public static int[] concatenar(int[]... vetores) {
    int comprimento = 0;
    for (int[] vetor : vetores) {
      comprimento += vetor.length;
    } 
    int[] ret = new int[comprimento];
    int destPos = 0;
    for (int[] vetor : vetores) {
      System.arraycopy (vetor, 0, ret, destPos, vetor.length);
      destPos += vetor.length;
    } 
    return ret;
  } 

  public static int[] insereIntVetor(int[] vetor, int indice) {
    int[] saida; indice--;
    if (indice == 0)
      saida = insereIntComeco(vetor);
    else if (indice == vetor.length - 1)
      saida = insereIntFinal(vetor);
    else {
      saida = new int[vetor.length + 1];
      int[] aux = {0};
      saida = concatenar(cortaVetor(vetor, indice),
                         aux, copiaVetor(vetor, indice));
    }
    return saida;
  } 
 
  public static int[] insereIntComeco(int[] vetor) {
    int[] aux = {0};
    return concatenar(aux, vetor);
  }
  public static int[] insereIntFinal(int[] vetor) {
    int[] aux = {0};
    return concatenar(vetor, aux);
  } 
  public static int[] removeIntVetor(int[] vetor, int indice) {
    int[] saida; indice--;
    if (indice == 0)
      saida = removeIntComeco(vetor);
    else if (indice == vetor.length - 1)
      saida = removeIntFinal(vetor);
    else {
      saida = new int[vetor.length - 1];
      saida = concatenar(cortaVetor(vetor, indice),
        copiaVetor(vetor, indice + 1));
    } 
    return saida;
  } 
  public static int[] removeIntComeco(int[] vetor) {
    return copiaVetor(vetor, 1);
  } 
  public static int[] removeIntFinal(int[] vetor) {
    return cortaVetor(vetor, vetor.length - 1);
  } 
}