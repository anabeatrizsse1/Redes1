package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static camadas.AplicacaoTransmissora.control;
import static camadas.CamadaDeAplicacaoTransmissora.*;
import static camadas.CamadaEnlaceDadosTransmissora.*;


public class CamadaEnlaceDadosReceptora {
  CamadaDeAplicacaoReceptora camadaApliReceptora = new CamadaDeAplicacaoReceptora();
  CamadaFisicaTransmissora camadaFisTransmissora;
  MetodosBit manipulador = new MetodosBit();
  int tipoDeEnquadramento = 0;
  int tipoDeControleDeErro = control.tipoControleDeErro;
  static boolean host2Enviando = false;
  static int contaErros = 0;
  static Semaphore stopAndWait2 = new Semaphore(0);
  static boolean verificaAck = false;

  public CamadaEnlaceDadosReceptora() {

  }

  public void CamadaEnlaceDadosReceptora(int quadro[]) {
    int quadroEnquadrado[];
    quadroEnquadrado = Enquadramento(quadro);
    quadroEnquadrado = camadaEnlaceDadosReceptoraControleDeErro(quadroEnquadrado);

    camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);
    if(quadroEnquadrado.length == 1){
      int verificaNak = manipulador.devolveNAK();
      verificaNak = manipulador.retornaPrimeiroByte(verificaNak);
      int quadroEnquadradoPrimeiroByte = manipulador.retornaPrimeiroByte(quadroEnquadrado[0]);
      if(quadroEnquadradoPrimeiroByte == verificaNak){
        enviarNak();
      }else{
        //envia ack
        enviarAck();
        camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);  
      }//fim else
    }else{
      //envia ack
      enviarAck();
      camadaApliReceptora.camadaAplicacaoReceptora(quadroEnquadrado);
    }//fim else
  }//fim metodo CamadaEnlanceDadosTransmissora

  public void enviarAck(){
    int ack[] = new int[1];
    //envia nak falando que quadro chegou com erro
    enlaceTransmissora.host1Enviando = false;
    host2Enviando = true;
    //envia nak
    ack[0] = manipulador.devolveAck();
    camadaFisTransmissora.binariaDireta(ack);
  }  

  public void enviarNak(){
    int nak[] = new int[1];
    //envia nak falando que quadro chegou com erro
    enlaceTransmissora.host1Enviando = false;
    host2Enviando = true;
    //envia nak
    nak[0] = manipulador.devolveNAK();
    camadaFisTransmissora.binariaDireta(nak);
  }
  public int[] Enquadramento(int quadro[]) {
    int quadroEnquadrado[];
    tipoDeEnquadramento = control.tipoDeEnquadramento;
    switch (tipoDeEnquadramento) {
      case 0: // contagem de caracteres
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(quadro);
        return quadroEnquadrado;
      case 1: // insercao de bytes
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes(quadro);
        return quadroEnquadrado;
      case 2: // insercao de bits
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits(quadro);
        return quadroEnquadrado;
      case 3: // violacao da camada fisica
        quadroEnquadrado = CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoDaCamadaFisica(quadro);
        return quadroEnquadrado;
    }
    return quadro;
  }

  public int[] camadaEnlaceDadosReceptoraControleDeErro(int quadro[]) {
    int quadroNovo[];
    switch (tipoDeControleDeErro) {
      case 0: // bit de paridade par
        quadroNovo = BitDeParidadePar(quadro);
        return quadroNovo;
      case 1: // bit de paridade impar
        quadroNovo = BitDeParidadeImpar(quadro);
        return quadroNovo;
      case 2: // CRC
        quadroNovo = ErroCRC(quadro);
        return quadroNovo;
      case 3: // codigo de hamming
        quadroNovo = codigoDeHamming(quadro);
        return quadroNovo;
    }
    return quadro;
  }
  public void CamadaEnlaceDadosReceptoraControleDeFluxo(int quadro []) {
    int tipoDeControleDeFluxo = 3; //alterar de acordo com o teste
    switch (tipoDeControleDeErro) {
      case 0:
        camadaEnlaceDadosReceptoraJanelaDeslizanteUmBit(quadro);
      break;
      case 1 : //protocolo de janela deslizante go-back-n
      //codigo
      break;
      case 2 : //protocolo de janela deslizante com retransmissão seletiva
      //codigo
      break;
    }
    }//fim do switch/case
    public void camadaEnlaceDadosReceptoraJanelaDeslizanteUmBit (int quadro []) {
      int tamQuadro = quadro.length;
    int quadroNumeroN[] = new int[1];
    int numIndice = 0;
    while(tamQuadro > 0){
      //instancia o timer
      Timer tempo = new Timer("host2");
      //envia quadro pro receptor
      quadroNumeroN[0] = quadro[numIndice];
      host2Enviando = true;
      enlaceTransmissora.host1Enviando = false;
      camadaFisTransmissora.CamadaFisicaTransmissora(quadroNumeroN);
      //chamada do metodo ativa timer
      tempo.start();
      // da um acquire 
      try{
        stopAndWait2.acquire();
      }catch(InterruptedException e){
        e.printStackTrace();
      }
      //timer termina ou ack chega
      if(verificaAck == true){
        numIndice++;
        tamQuadro--;
        verificaAck = false;
      }//fim if
      else{
        if(contaErros == 0){
          LblImg ativar = new LblImg();
          ativar.start();
        }//fim if
        contaErros++;
      }//fim else
      //verifica se a variavel verificaAck eh false, se for reenvia e nao diminui tamQuadro, se for true envia o proximo quadro e diminui tamQuadro
    }//fim while
    //envia um indice do quadro, ativa timer espera confirmação, nao chegou ? reenvia o quadro
    //vai no quadro o que ja ta adicionando, o nº do quadro que esta sendo enviado, e a confirmacao do quadro do host2
  }//fim do metodo CamadaEnlaceDadosTransmissoraJanelaDeslizanteUmBit

    
  public int[] ErroCRC(int quadro[]) {
    int crc32 = manipulador.devolveCrc();
    int resto = 0;
    int inteiro = 0;
    int bit = 0;
    boolean verif = false;
    int cont = 0;
    int quadrosCRC[] = new int[quadro.length / 2];

    for (int i = 0; i < quadro.length; i++) {
      if (i % 2 == 0) {
        resto = 0;
        crc32 = manipulador.devolveCrc();
        int contador = 0;
        inteiro = quadro[i];
        verif = false;
        if ((manipulador.retornarBitNaPosicao(inteiro, 0)) == 0) {
          inteiro <<= 1;
          verif = true;
        }
        contador = 0;
        while (contador < 32) {
          bit = ((manipulador.retornarBitNaPosicao(inteiro, 0)) ^ (manipulador.retornarBitNaPosicao(crc32, 0))) == 0 ? 0
              : 1;
          resto <<= 1;
          resto |= bit;

          crc32 <<= 1;
          inteiro <<= 1;
          contador++;
          if (verif == true && contador == 31) {
            bit = manipulador.retornarBitNaPosicao(crc32, 0);
            resto <<= 1;
            resto |= bit;
            quadrosCRC[cont] = resto;
            cont++;
            break;
          }
        }
        if (verif == false) {
          quadrosCRC[i] = resto;
          break;
        }
      }
    }
  
    int quadrosCrcOriginal[] = new int[quadrosCRC.length];
    int contCrc = 0;
    for (int i = 0; i < quadro.length; i++) {
      if (i % 2 != 0) {
        quadrosCrcOriginal[contCrc] = quadro[i];
        contCrc++;
      }
    }

    int inteiroCrc1 = 0;
    int inteiroCrc2 = 0;
    int contaIndice = 0;
    int indiceQuadro = 0;
    int quadrosAtransmitir[] = new int[quadro.length];
    for (int i = 0; i < quadrosCRC.length; i++) {
      int contador = 0;
      resto = 0;
      inteiroCrc1 = quadrosCrcOriginal[i];
      inteiroCrc2 = quadrosCRC[i];
      while (contador < 32) {

        bit = ((manipulador.retornarBitNaPosicao(inteiroCrc1, 0))
            ^ (manipulador.retornarBitNaPosicao(inteiroCrc2, 0))) == 0 ? 0 : 1;
        resto <<= 1;
        resto |= bit;

        inteiroCrc1 <<= 1;
        inteiroCrc2 <<= 1;
        contador++;
      }
      if (resto == 0) {
        quadrosAtransmitir[contaIndice] = quadro[indiceQuadro];
        contaIndice++;
        indiceQuadro += 2;
      } else {
        int quadroComErro[] = new int[1];
        quadrosAtransmitir[contaIndice] = manipulador.devolveERRO();
        quadroComErro[0] = manipulador.devolveERRO();
        contaIndice++;
        indiceQuadro += 2;
        return quadroComErro;
      }
    }
    return quadrosAtransmitir;
  }

  public int[] BitDeParidadePar(int quadro[]) {
    int quadrosAtransmitir[] = new int[quadro.length];
    for (int i = 0; i < quadro.length; i++) {
      if ((manipulador.quantidadeBits1Inteiro(quadro[i])) % 2 == 0) {
        quadro[i] >>= 16;
        quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
        quadrosAtransmitir[i] = quadro[i];
      } else {
        quadrosAtransmitir[i] = manipulador.devolveERRO();
        int quadroComErro[] = new int[1];
        quadroComErro[0] = manipulador.devolveERRO();
        return quadroComErro;
      }
    }
    return quadrosAtransmitir;
  }

  public int[] BitDeParidadeImpar(int quadro[]) {
    int quadrosAtransmitir[] = new int[quadro.length];
    for (int i = 0; i < quadro.length; i++) {
      if ((manipulador.quantidadeBits1Inteiro(quadro[i])) % 2 != 0) {
        quadro[i] >>= 16;
        quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
        quadrosAtransmitir[i] = quadro[i];
      } else {
        quadrosAtransmitir[i] = manipulador.devolveERRO();
        int quadroComErro[] = new int[1];
        quadroComErro[0] = manipulador.devolveERRO();
        return quadroComErro;
      }
    }
    return quadrosAtransmitir;
  }

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoContagemDeCaracteres(int quadro[]) {
    if (tipoDeControleDeErro == 2) {
      for (int j = 0; j < quadro.length; j++) {
        if (j % 2 == 0) {
          quadro[j] <<= 8;
        }
      }
    } else {
      for (int j = 0; j < quadro.length; j++) {
        quadro[j] <<= 8;
      }
    }
    return quadro;
  }

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBytes(int quadro[]) {
    if (tipoDeControleDeErro == 2) {
      for (int j = 0; j < quadro.length; j++) {
        if (j % 2 == 0) {
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 24);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 23);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 22);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 21);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 20);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 19);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 18);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 17);
          quadro[j] <<= 8;
        }
      }
    } else {
      for (int j = 0; j < quadro.length; j++) {
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 24);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 23);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 22);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 21);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 20);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 19);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 18);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 17);
        quadro[j] <<= 8;
      }
    }

    return quadro;
  }

  private int[] codigoDeHamming(int[] quadro) {
    quadro = MetodosBit.transformaInteiroEmbits(quadro);
    int contador = 0, temp = 0;
    while (temp < quadro.length) {
      if (Math.pow(2, contador) == temp + contador + 1)
        contador++;
      else
        temp++;
    }
    if (quadro.length > 32) {
      contador--;
    }
    int limite = quadro.length + contador - 32;
    quadro = Vetor.cortaVetor(quadro, limite);
    int contErro = 0;
    for (int i = 0; i < contador; i++) {
      List<Integer> posicoes = new ArrayList();
      for (int m = 1; m <= quadro.length; m++) {
        if (!MetodosBit.potenciaDeDois(m)) {
          int n = m;
          int potencia = 0;
          while (n != 0) {
            if ((n & 1) != 0 && potencia == i) {
              posicoes.add(m);
              break;
            }
            ++potencia;
            n >>>= 1;
          }
        }
      }
      int paridade = quadro[posicoes.remove(0) - 1];
      while (!posicoes.isEmpty())
        paridade = paridade ^ quadro[posicoes.remove(0) - 1];
      if (paridade != quadro[(int) (Math.pow(2, i) - 1)]) {
        contErro += (int) Math.pow(2, i);
      }
    }
    contErro--;
    if ((contErro + 1) != 0) {
      quadro = MetodosBit.inverteBits(quadro, contErro, 31);
      for (int i = 0, k = 0; i < contador; i++, k++) {
        quadro = Vetor.removeIntVetor(quadro, ((int) Math.pow(2, i)) - k);
      }
      int[] saida = MetodosBit.desfazVetorBits(quadro);
      Enquadramento(saida);
    }
    return quadro;

  }

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoInsercaoDeBits(int quadro[]) {
    int mask = 1;
    int bit = 0;
    int bit2 = 0;
    int bit3 = 0;
    int bitUm = 0;
    int inteiro = 0;
    int umBitaFrente = 0;
    int umBitaFrente2 = 0;

    if (tipoDeControleDeErro == 2) {
      for (int j = 0; j < quadro.length; j++) {
        if (j % 2 == 0) {
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 24);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 23);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 22);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 21);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 20);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 19);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 18);
          quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 17);
          quadro[j] <<= 8;

          if (manipulador.retornaPrimeiroByte2(quadro[j]) == 0) {
            quadro[j] >>= 16;
            inteiro = quadro[j];
            umBitaFrente = inteiro >> 1;
            umBitaFrente2 = umBitaFrente >> 1;
            while (true) {
              bit = (inteiro & mask) == 0 ? 0 : 1;
              bit2 = (umBitaFrente & mask) == 0 ? 0 : 1;
              bit3 = (umBitaFrente2 & mask) == 0 ? 0 : 1;
              if (bit == 0 && bit2 == 0 && bit3 == 1) {
                inteiro >>= 1;
                quadro[j] = inteiro;
                break;
              } else {
                inteiro >>= 1;
                umBitaFrente >>= 1;
                umBitaFrente2 >>= 2;
              }
            }
          } else {
            quadro[j] >>= 24;
          }
        }
      }
    } else {
      for (int j = 0; j < quadro.length; j++) {
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 24);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 23);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 22);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 21);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 20);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 19);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 18);
        quadro[j] = manipulador.colocarBitNaPosicao(quadro[j], 0, 17);
        quadro[j] <<= 8;

        if (manipulador.retornaPrimeiroByte2(quadro[j]) == 0) {
          quadro[j] >>= 16;
          inteiro = quadro[j];
          umBitaFrente = inteiro >> 1;
          umBitaFrente2 = umBitaFrente >> 1;
          while (true) {
            bit = (inteiro & mask) == 0 ? 0 : 1;
            bit2 = (umBitaFrente & mask) == 0 ? 0 : 1;
            bit3 = (umBitaFrente2 & mask) == 0 ? 0 : 1;
            if (bit == 0 && bit2 == 0 && bit3 == 1) {
              inteiro >>= 1;
              quadro[j] = inteiro;
              break;
            } else {
              inteiro >>= 1;
              umBitaFrente >>= 1;
              umBitaFrente2 >>= 2;
            }
          }
        }
      }
    }
    if (tipoDeControleDeErro == 2) {
      for (int i = 0; i < quadro.length; i++) {
        if (i % 2 == 0) {
          quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
        } else {
        }
      }
    } else {
      for (int i = 0; i < quadro.length; i++) {
        quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
      }
    }
    return quadro;
  }

  public int[] CamadaDeEnlaceDadosReceptoraEnquadramentoViolacaoDaCamadaFisica(int quadro[]) {
    int[] novoQuadro = new int[quadro.length];
    int contador = 0;
    int bit = 0;
    int mask = 1 << 31;

    if (tipoDeControleDeErro == 2) {
      for (int j = 0; j < quadro.length; j++) {
        if (j % 2 == 0) {
          contador = 0;
          quadro[j] <<= 8;
          while (contador < 8) {
            bit = (quadro[j] & mask) == 0 ? 0 : 1;

            novoQuadro[j] <<= 1;
            novoQuadro[j] = novoQuadro[j] | bit;
            quadro[j] <<= 2;
            contador++;
          }
        }
      }
    } else {
      for (int j = 0; j < quadro.length; j++) {
        int temp = 0;
        contador = 0;
        quadro[j] <<= 8;
        temp = manipulador.retornarBitNaPosicao(quadro[j], 16);
        while (contador < 32) {
          bit = (quadro[j] & mask) == 0 ? 0 : 1;

          novoQuadro[j] <<= 1;
          novoQuadro[j] = novoQuadro[j] | bit;
          quadro[j] <<= 2;
          contador++;
        }
        novoQuadro[j] = manipulador.colocarBitNaPosicao(novoQuadro[j], 0, 9);
        novoQuadro[j] = manipulador.colocarBitNaPosicao(novoQuadro[j], temp, 17);
      }
    }
    if (tipoDeControleDeErro == 2) {
      for (int i = 0; i < quadro.length; i++) {
        if (i % 2 == 0) {
          novoQuadro[i] = manipulador.moverBitsEsquerda(novoQuadro[i]);
        } else {
          novoQuadro[i] = quadro[i];
        }
      }
    } else {
      for (int i = 0; i < quadro.length; i++) {
        novoQuadro[i] = manipulador.moverBitsEsquerda(novoQuadro[i]);
      }
    }
    return novoQuadro;
  }
}