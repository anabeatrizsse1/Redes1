package camadas;

import controlador.Controlador;
import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import static camadas.AplicacaoTransmissora.control;

public class CamadaEnlaceDadosTransmissora {
  // Controlador control;
  CamadaFisicaTransmissora camadaFisTransmissora = new CamadaFisicaTransmissora();
  MetodosBit manipulador = new MetodosBit();
  int tipoDeEnquadramento = 0;
  int tipoDeControleDeErro = control.tipoControleDeErro;

  public CamadaEnlaceDadosTransmissora() {

  }

  public void CamadaEnlaceDadosTransmissora(int quadro[]) {
    int quadroEnquadrado[];

    quadroEnquadrado = CamadaEnlaceDadosTransmissoraEnquadramento(quadro);
    quadroEnquadrado = camadaEnlaceDadosTransmissoraControleDeErro(quadroEnquadrado);

    camadaFisTransmissora.CamadaFisicaTransmissora(quadroEnquadrado);
  }

  public int[] CamadaEnlaceDadosTransmissoraEnquadramento(int quadro[]) {
    tipoDeEnquadramento = control.tipoDeEnquadramento;
    int quadroEnquadrado[];
    int temp[] = new int[2];
    switch (tipoDeEnquadramento) {
      case 0:
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres(quadro);
        return quadroEnquadrado;
      case 1:
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBytes(quadro);
        return quadroEnquadrado;
      case 2:
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBits(quadro);
        return quadroEnquadrado;
      case 3:
        quadroEnquadrado = CamadaDeEnlaceDadosTransmissoraEnquadramentoViolacaoDaCamadaFisica(quadro);
        return quadroEnquadrado;
    }
    return temp;
  }

  public int[] camadaEnlaceDadosTransmissoraControleDeErro(int quadro[]) {
    int quadroNovo[];
    switch (tipoDeControleDeErro) {
      case 0: // bit de paridade par
        quadroNovo = BitParidadePar(quadro);
        return quadroNovo;
      case 1: // bit de paridade impar
        quadroNovo = BitParidadeImpar(quadro);
        return quadroNovo;
      case 2: // CRC
        quadroNovo = DeErroCRC(quadro);
        return quadroNovo;
      case 3: // codigo de Hamming
        quadroNovo = codigoDeHamming(quadro);
        return quadro;
    }
    return quadro;
  }

  public int[] BitParidadePar(int quadro[]) {
    int bits1Areduzir = 0;
    if (tipoDeEnquadramento == 0) {
      bits1Areduzir = 3;
    } else if (tipoDeEnquadramento == 1) {
      bits1Areduzir = 10;
    } else if (tipoDeEnquadramento == 2) {
      bits1Areduzir = 12;
    }

    if (tipoDeEnquadramento == 3) {
      int novoQuadro[] = new int[quadro.length];
      int bit = 0;
      int mask = 1 << 31;
      int inteiro = 0;
      for (int j = 0; j < quadro.length; j++) {
        int temp = 0;
        int contador = 0;
        inteiro = quadro[j];
        inteiro <<= 8;
        while (contador < 32) {
          bit = (inteiro & mask) == 0 ? 0 : 1;

          novoQuadro[j] <<= 1;
          novoQuadro[j] = novoQuadro[j] | bit;
          inteiro <<= 2;
          contador++;
        }
      }
      for (int i = 0; i < quadro.length; i++) {
        quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
        if ((manipulador.quantidadeBits1Inteiro(novoQuadro[i])) % 2 == 0) {
        } else {
          quadro[i] = manipulador.colocarBitNaPosicao(quadro[i], 1, 25);
        }
      }
    } else {
      for (int i = 0; i < quadro.length; i++) {
        quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
        if ((manipulador.quantidadeBits1Inteiro(quadro[i]) - bits1Areduzir) % 2 == 0) {
        } else {
          quadro[i] = manipulador.colocarBitNaPosicao(quadro[i], 1, 25);
        }
      }
    }
    return quadro;
  }

  public int[] BitParidadeImpar(int quadro[]) {
    int bits1Areduzir = 0;
    if (tipoDeEnquadramento == 0) {
      bits1Areduzir = 3;
    } else if (tipoDeEnquadramento == 1) {
      bits1Areduzir = 10;
    } else if (tipoDeEnquadramento == 2) {
      bits1Areduzir = 12;
    }

    if (tipoDeEnquadramento == 3) {
      int novoQuadro[] = new int[quadro.length];
      int bit = 0;
      int mask = 1 << 31;
      int inteiro = 0;
      for (int j = 0; j < quadro.length; j++) {
        int temp = 0;
        int contador = 0;
        inteiro = quadro[j];
        inteiro <<= 8;
        while (contador < 32) {
          bit = (inteiro & mask) == 0 ? 0 : 1;

          novoQuadro[j] <<= 1;
          novoQuadro[j] = novoQuadro[j] | bit;
          inteiro <<= 2;
          contador++;
        }
      }
      for (int i = 0; i < quadro.length; i++) {
        quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
        if ((manipulador.quantidadeBits1Inteiro(novoQuadro[i])) % 2 != 0) {
        } else {
          quadro[i] = manipulador.colocarBitNaPosicao(quadro[i], 1, 25);
        }
      }
    } else {
      for (int i = 0; i < quadro.length; i++) {
        quadro[i] = manipulador.moverBitsEsquerda(quadro[i]);
        if ((manipulador.quantidadeBits1Inteiro(quadro[i]) - bits1Areduzir) % 2 != 0) {
        } else {
          quadro[i] = manipulador.colocarBitNaPosicao(quadro[i], 1, 25);
        }
      }
    }
    return quadro;
  }

  private int[] codigoDeHamming(int[] quadro) {
    quadro = MetodosBit.transformaInteiroEmbits(quadro);

    int contador = 0, temp = 0;
    while (temp < quadro.length) {
      if (Math.pow(2, contador) == temp + contador + 1)
        contador++;
      else
        temp++;
    }
    if (!MetodosBit.potenciaDeDois(quadro.length - 32)) {
      contador--;
    }

    for (int i = 0; i < contador; i++)
      quadro = Vetor.insereIntVetor(quadro, (int) Math.pow(2, i));

    for (int i = 0; i < contador; i++) {

      List<Integer> posicoes = new ArrayList();
      for (int m = 1; m <= quadro.length; m++) {
        if (!MetodosBit.potenciaDeDois(m)) {
          int n = m;
          int potencia = 0;
          while (n != 0) {
            if ((n & 1) != 0 && potencia == i) {
              posicoes.add(m);
              break;
            }
            ++potencia;
            n >>>= 1;
          }
        }
      }
      int paridade = quadro[posicoes.remove(0) - 1];
      while (!posicoes.isEmpty())
        paridade = paridade ^ quadro[posicoes.remove(0) - 1];
      quadro[(int) Math.pow(2, i) - 1] = paridade;
    }
    int[] saida = MetodosBit.desfazVetorBits(quadro);
    return saida;
  }

  public int[] DeErroCRC(int quadro[]) {
    int quadroNovo[] = new int[quadro.length * 2];
    int crc32 = manipulador.devolveCrc();
    int resto = 0;
    int inteiro = 0;
    int bit = 0;
    boolean verif = false;
    int cont = 0;

    for (int j = 0; j < quadroNovo.length; j++) {
      if (j % 2 == 0 && j != 0) {
        quadroNovo[j] = quadro[cont];
        quadroNovo[j] = manipulador.moverBitsEsquerda(quadroNovo[j]);
        cont++;
      } else if (j == 0) {
        quadroNovo[j] = quadro[j];
        quadroNovo[j] = manipulador.moverBitsEsquerda(quadroNovo[j]);
        cont++;
      }
    }

    for (int i = 0; i < quadro.length; i++) {
      resto = 0;
      crc32 = manipulador.devolveCrc();
      int contador = 0;
      inteiro = quadro[i];

      if (tipoDeEnquadramento == 0) {
        inteiro <<= 16;
        inteiro = manipulador.moverBitsEsquerda(inteiro);
      } else if (tipoDeEnquadramento == 1) {
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 24);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 23);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 22);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 21);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 20);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 19);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 18);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 17);
        inteiro <<= 8;
        inteiro = manipulador.moverBitsEsquerda(inteiro);
      } else if (tipoDeEnquadramento == 2) {
        int mask = 1;
        int bit2 = 0;
        int bit3 = 0;
        int bitUm = 0;
        int umBitaFrente = 0;
        int umBitaFrente2 = 0;

        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 24);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 23);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 22);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 21);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 20);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 19);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 18);
        inteiro = manipulador.colocarBitNaPosicao(inteiro, 0, 17);
        inteiro <<= 8;

        if (manipulador.retornaPrimeiroByte2(inteiro) == 0) {
          inteiro >>= 16;
          umBitaFrente = inteiro >> 1;
          umBitaFrente2 = umBitaFrente >> 1;
          while (true) {
            bit = (inteiro & mask) == 0 ? 0 : 1;
            bit2 = (umBitaFrente & mask) == 0 ? 0 : 1;
            bit3 = (umBitaFrente2 & mask) == 0 ? 0 : 1;
            if (bit == 0 && bit2 == 0 && bit3 == 1) {
              inteiro >>= 1;
              break;
            } else {
              inteiro >>= 1;
              umBitaFrente >>= 1;
              umBitaFrente2 >>= 2;
            }
          }
        } else {
          inteiro >>= 24;
        }
        inteiro = manipulador.moverBitsEsquerda(inteiro);
      } else if (tipoDeEnquadramento == 3) {
        int mask = 1 << 31;
        contador = 0;
        inteiro <<= 8;

        int novoInt = 0;

        while (contador < 8) {
          bit = (inteiro & mask) == 0 ? 0 : 1;

          novoInt <<= 1;
          novoInt |= bit;
          inteiro <<= 2;
          contador++;
        }
        inteiro = novoInt;
        contador = 0;
        inteiro = manipulador.moverBitsEsquerda(inteiro);
      }
      verif = false;
      if ((manipulador.retornarBitNaPosicao(inteiro, 0)) == 0) {
        inteiro <<= 1;
        verif = true;
      }
      contador = 0;
      while (contador < 32) {

        bit = ((manipulador.retornarBitNaPosicao(inteiro, 0)) ^ (manipulador.retornarBitNaPosicao(crc32, 0))) == 0 ? 0
            : 1;
        resto <<= 1;
        resto |= bit;

        crc32 <<= 1;
        inteiro <<= 1;
        contador++;
        if (verif == true && contador == 31) {
          bit = manipulador.retornarBitNaPosicao(crc32, 0);
          resto <<= 1;
          resto |= bit;
          for (int c = 0; c < quadroNovo.length; c++) {
            if (quadroNovo[c] == 0) {
              quadroNovo[c] = resto;
              break;
            }
          }
          break;
        }
      }
      if (verif == false) {
        for (int c = 0; c < quadroNovo.length; c++) {
          if (quadroNovo[c] == 0) {
            quadroNovo[c] = resto;
            break;
          }
        }
      }
    }
    return quadroNovo;
  }

  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoContagemDeCaracteres(int quadro[]) {
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    int[] informacaoDeControle = new int[quadro.length];

    for (int i = 0; i < quadro.length; i++) {
      informacaoDeControle[i] = (manipulador.retornaBitsSignificativos(quadro[i])) / 8;
      acumulador += informacaoDeControle[i];
    }

    if (acumulador > 2) {
      while (acumulador > 2) {
        acumulador -= 2;
        qtdIndices++;
      }
      qtdIndices += 1;
    } else {
      qtdIndices = 1;
    }

    int[] novoQuadro = new int[qtdIndices];

    for (int m = 0; m < quadro.length; m++) {
      quadro[m] = manipulador.moverBitsEsquerda(quadro[m]);
    }
    for (int j = 0; j < quadro.length; j++) {
      cont = 0;
      inteiro = quadro[j];
      while (cont < 32) {
        bit = (inteiro & mask) == 0 ? 0 : 1;

        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;

        inteiro <<= 1;
        cont++;
        cont2++;
        if (cont2 % 16 == 0 && cont2 != 0) {

          if (indiceNvQ == novoQuadro.length - 1) {
            if (acumulador == 1) {
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 49;
            } else if (acumulador == 2) {
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 50;
            } else if (acumulador == 3) {
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 51;
            }
          } else {
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 50;

          }
          int contador = 0;

          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          while (contador < 16) {
            bit = (novoInteiro & mask) == 0 ? 0 : 1;

            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }

          if (indiceNvQ < qtdIndices - 1) {
            indiceNvQ += 1;
          } else {
            break;
          }
          novoInteiro = 0;
          cont2 = 0;
        }
        if (cont == 32 && j == quadro.length - 1 && novoInteiro != 0) {
          int contador = 0;
          if (acumulador == 1) {
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 49;
          } else if (acumulador == 2) {
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 50;
          } else if (acumulador == 3) {
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 51;
          }
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          while (contador < (acumulador * 8)) {
            bit = (novoInteiro & mask) == 0 ? 0 : 1;

            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }

          if (acumulador * 8 == 8) {
            novoQuadro[indiceNvQ] <<= 16;
          } else if (acumulador * 8 == 16) {
            novoQuadro[indiceNvQ] <<= 8;
          }
        }
      }
    }

    return novoQuadro;
  }

  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBytes(int quadro[]) {
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    int[] informacaoDeControle = new int[quadro.length];

    for (int i = 0; i < quadro.length; i++) {
      informacaoDeControle[i] = (manipulador.retornaBitsSignificativos(quadro[i])) / 8;
      acumulador += informacaoDeControle[i];
    }

    qtdIndices = acumulador;

    int[] novoQuadro = new int[acumulador];

    for (int m = 0; m < quadro.length; m++) {
      quadro[m] = manipulador.moverBitsEsquerda(quadro[m]);
    }

    for (int j = 0; j < quadro.length; j++) {
      cont = 0;
      inteiro = quadro[j];
      while (cont < 32) {
        bit = (inteiro & mask) == 0 ? 0 : 1;

        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;

        inteiro <<= 1;
        cont++;
        cont2++;
        if (cont2 % 8 == 0 && cont2 != 0) {

          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 31;

          int contador = 0;

          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          while (contador < 8) {
            bit = (novoInteiro & mask) == 0 ? 0 : 1;

            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }
          int flag = 31;
          contador = 0;
          flag = manipulador.moverBitsEsquerda(flag);
          while (contador < 8) {
            bit = (flag & mask) == 0 ? 0 : 1;

            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
          }

          novoQuadro[indiceNvQ] <<= 8;

          if (indiceNvQ < qtdIndices - 1) {
            indiceNvQ += 1;
          } else {
            break;
          }
          novoInteiro = 0;
          cont2 = 0;
        }
        if (cont == 32 && j == quadro.length - 1 && novoInteiro != 0) {
          int contador = 0;

          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 31;

          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          while (contador < 8) {
            bit = (novoInteiro & mask) == 0 ? 0 : 1;

            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }

          int flag = 31;
          contador = 0;
          flag = manipulador.moverBitsEsquerda(flag);
          while (contador < 8) {
            bit = (flag & mask) == 0 ? 0 : 1;

            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
          }

          novoQuadro[indiceNvQ] <<= 8;

        }
      }
    }
    return novoQuadro;
  }

  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoInsercaoDeBits(int quadro[]) {
    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    int[] informacaoDeControle = new int[quadro.length];

    for (int i = 0; i < quadro.length; i++) {
      informacaoDeControle[i] = (manipulador.retornaBitsSignificativos(quadro[i])) / 8;
      acumulador += informacaoDeControle[i];
    }
    qtdIndices = acumulador;

    int[] novoQuadro = new int[acumulador];

    for (int m = 0; m < quadro.length; m++) {
      quadro[m] = manipulador.moverBitsEsquerda(quadro[m]);
    }

    for (int j = 0; j < quadro.length; j++) {
      cont = 0;
      inteiro = quadro[j];
      while (cont < 32) {
        bit = (inteiro & mask) == 0 ? 0 : 1;

        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        inteiro <<= 1;
        cont++;
        cont2++;
        if (cont2 % 8 == 0 && cont2 != 0) {
          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 126;
          int contador = 0;

          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          int contaUm = 0;

          if (manipulador.verificaCincoBitsSequenciais(novoInteiro, 1) == true) {
            novoQuadro[indiceNvQ] <<= 7;
            while (contador < 8) {
              bit = (novoInteiro & mask) == 0 ? 0 : 1;

              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              contador++;
              if (bit == 1) {
                contaUm++;
                if (contaUm == 5) {
                  novoQuadro[indiceNvQ] <<= 1;
                  novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 0;
                  contaUm = 0;
                }
              }
            }
          } else {
            while (contador < 8) {
              bit = (novoInteiro & mask) == 0 ? 0 : 1;

              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              contador++;
            }
          }

          int flag = 126;
          contador = 0;
          flag = manipulador.moverBitsEsquerda(flag);
          while (contador < 8) {
            bit = (flag & mask) == 0 ? 0 : 1;

            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
          }

          if (indiceNvQ < qtdIndices - 1) {
            indiceNvQ += 1;
          } else {
            break;
          }
          novoInteiro = 0;
          cont2 = 0;
        }
        if (cont == 32 && j == quadro.length - 1 && novoInteiro != 0) {
          int contador = 0;

          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 126;
          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          int contaUm = 0;

          if (manipulador.verificaCincoBitsSequenciais(novoInteiro, 1) == true) {
            novoQuadro[indiceNvQ] <<= 7;
            while (contador < 8) {
              bit = (novoInteiro & mask) == 0 ? 0 : 1;

              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;

              contador++;
              if (bit == 1) {
                contaUm++;
                if (contaUm == 5) {
                  novoQuadro[indiceNvQ] <<= 1;
                  novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 0;
                  contaUm = 0;
                }
              }
            }
          } else {
            while (contador < 8) {
              bit = (novoInteiro & mask) == 0 ? 0 : 1;

              novoQuadro[indiceNvQ] <<= 1;
              novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
              novoInteiro <<= 1;
              contador++;
            }
          }

          int flag = 126;
          contador = 0;
          flag = manipulador.moverBitsEsquerda(flag);
          while (contador < 8) {
            bit = (flag & mask) == 0 ? 0 : 1;

            novoQuadro[indiceNvQ] <<= 1;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            flag <<= 1;
            contador++;
          }

          novoQuadro[indiceNvQ] <<= 8;

        }
      }
    }

    for (int i = 0; i < novoQuadro.length; i++) {
      novoQuadro[i] = manipulador.moverBitsEsquerda(novoQuadro[i]);
    }

    return novoQuadro;
  }

  public int[] CamadaDeEnlaceDadosTransmissoraEnquadramentoViolacaoDaCamadaFisica(int quadro[]) {

    int indiceNvQ = 0;
    int cont = 0;
    int cont2 = 0;
    int inteiro = 0;
    int mask = 1 << 31;
    int bit = 0;
    int novoInteiro = 0;
    int acumulador = 0;
    int qtdIndices = 0;

    int[] informacaoDeControle = new int[quadro.length];

    for (int i = 0; i < quadro.length; i++) {
      informacaoDeControle[i] = (manipulador.retornaBitsSignificativos(quadro[i])) / 8;
      acumulador += informacaoDeControle[i];
    }

    qtdIndices = acumulador;

    int[] novoQuadro = new int[acumulador];

    for (int m = 0; m < quadro.length; m++) {
      quadro[m] = manipulador.moverBitsEsquerda(quadro[m]);
    }

    for (int j = 0; j < quadro.length; j++) {
      cont = 0;
      inteiro = quadro[j];
      while (cont < 32) {
        bit = (inteiro & mask) == 0 ? 0 : 1;

        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        inteiro <<= 1;
        cont++;
        cont2++;
        if (cont2 % 8 == 0 && cont2 != 0) {

          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 3;
          int contador = 0;

          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          int contaUm = 0;

          novoQuadro[indiceNvQ] <<= 6;

          while (contador < 8) {
            bit = (novoInteiro & mask) == 0 ? 1 : 2;

            novoQuadro[indiceNvQ] <<= 2;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }

          novoQuadro[indiceNvQ] <<= 8;

          if (indiceNvQ < qtdIndices - 1) {
            indiceNvQ += 1;
          } else {
            break;
          }
          novoInteiro = 0;
          cont2 = 0;
        }
        if (cont == 32 && j == quadro.length - 1 && novoInteiro != 0) {

          novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | 3;
          int contador = 0;

          novoInteiro = manipulador.moverBitsEsquerda(novoInteiro);

          int contaUm = 0;

          novoQuadro[indiceNvQ] <<= 8;

          while (contador < 8) {
            bit = (novoInteiro & mask) == 0 ? 1 : 2;
            novoQuadro[indiceNvQ] <<= 2;
            novoQuadro[indiceNvQ] = novoQuadro[indiceNvQ] | bit;
            novoInteiro <<= 1;
            contador++;
          }

          novoQuadro[indiceNvQ] <<= 8;

          if (indiceNvQ < qtdIndices - 1) {
            indiceNvQ += 1;
          } else {
            break;
          }
          novoInteiro = 0;
          cont2 = 0;

        }
      }
    }

    for (int i = 0; i < novoQuadro.length; i++) {
      novoQuadro[i] = manipulador.moverBitsEsquerda(novoQuadro[i]);
    }

    return novoQuadro;

  }

}