package camadas;

public class MetodosBit {

  public static String devolveBits(int numero) {
    String bits = "";
    int displayMask = 1 << 31;
    for (int bit = 1; bit <= 32; bit++) {
      System.out.print((numero & displayMask) == 0 ? '0' : '1');
      bits += (numero & displayMask) == 0 ? '0' : '1';
      numero <<= 1;
      if (bit % 8 == 0) {
        System.out.print(" ");
        bits += " ";
      }
    }
    System.out.println();
    return bits;
  }

  public int[] moverParaEsquerda(int[] quadro) {
    for (int i = 0; i < quadro.length; i++) {
      int cont = 0;
      int inteiro = quadro[i];
      int umBitaFrente = inteiro;
      int mask = 1 << 31;
      umBitaFrente <<= 1;
      while ((umBitaFrente & mask) == 0) {
        umBitaFrente <<= 1;
        inteiro <<= 1;
      }
      quadro[i] = inteiro;
    }

    return quadro;
  }

  public int moverParaEsquerdaInteiro(int quadro) {
    int cont = 0;
    int inteiro = quadro;
    int umBitaFrente = inteiro;
    int mask = 1 << 31;
    umBitaFrente <<= 1;
    while ((umBitaFrente & mask) == 0) {
      umBitaFrente <<= 1;
      inteiro <<= 1;
    }
    quadro = inteiro;

    return quadro;
  }

  public int[] moverParaDireita(int[] quadro) {
    for (int i = 0; i < quadro.length; i++) {
      int inteiro = quadro[i];
      int mask = 1 << 31;
      while ((inteiro & mask) == 0) {
        inteiro >>= 1;
      }
      quadro[i] = inteiro;
    }

    return quadro;
  }

  public static int[] inteiroEmBits(int[] vetorDeInteiros) {

    int novoTamanho = vetorDeInteiros.length / 4;
   
    if (vetorDeInteiros.length % 4 != 0) {
      novoTamanho++;
    }

    int[] vetorDeBits = new int[novoTamanho];

    int novoBit = 0;
    int posicaoV = 0;
    int posicaoR = 0;

    while (posicaoV < vetorDeInteiros.length) {
      novoBit <<= 8;
      novoBit = novoBit | vetorDeInteiros[posicaoV];

      if ((posicaoV + 1) % 4 == 0) {
        vetorDeBits[posicaoR] = novoBit;
        novoBit = 0;
        posicaoR++;
      }

      posicaoV++;
    } 

    if (novoBit != 0) {
      vetorDeBits[posicaoR] = novoBit;
    }

    return vetorDeBits;
  }

  public static int[] transformaInteiroEmbits(int[] vetorDeBits) {
    int adicionar = 0;
    int reduzir = 0;
    int tamanho = vetorDeBits.length;
    int numeroDeBitsUltimoInteiro = Integer.toBinaryString(vetorDeBits[vetorDeBits.length - 1]).length();

   
    if (numeroDeBitsUltimoInteiro <= 24) {

      if (numeroDeBitsUltimoInteiro <= 8) {
        adicionar += 1;
      } else if (numeroDeBitsUltimoInteiro <= 16) {
        adicionar += 2;
      } else if (numeroDeBitsUltimoInteiro <= 24) {
        adicionar += 3;
      }

      reduzir = 1;
        }

    int novoTamanho = ((tamanho - reduzir) * 4) + adicionar;

    int[] vetorDeInteiros = new int[novoTamanho];

    int displayMask = 1 << 31;
    int posicaoI = 0;

    for (int intBits : vetorDeBits) {
      int novoInteiro = 0;

      for (int i = 1; i <= 32; i++) {
        int bit = (intBits & displayMask) == 0 ? 0 : 1;
        novoInteiro <<= 1;
        novoInteiro = novoInteiro | bit;
        intBits <<= 1;

        if (i % 8 == 0 && novoInteiro != 0) {
          vetorDeInteiros[posicaoI] = novoInteiro;
          posicaoI++;
          novoInteiro = 0;
        }
      } 

    } 

    return vetorDeInteiros;
  }

  public static int transferirBits(int numero, int bitsParaInserir) {
    int quantidadeDeBitsNumero = retornaBitsSignificativos(numero);
    int quantidadeDeBitsDeslocar = retornaBitsSignificativos(bitsParaInserir);

    if ((quantidadeDeBitsNumero + quantidadeDeBitsDeslocar) > 32) {
      System.out.println("[Erro] ao tentar Inserir Bits");
      return numero;
    }

    numero <<= quantidadeDeBitsDeslocar;
    numero = numero | bitsParaInserir;
    return numero;
  }

  public static int retornaPrimeiroByte(int numero) {
    int primeiroByte = 0;
    numero = moverBitsEsquerda(numero);

    int displayMask = 1 << 31;
    for (int i = 1; i <= 8; i++) {
      int bit = (numero & displayMask) == 0 ? 0 : 1;
      primeiroByte <<= 1;
      primeiroByte = primeiroByte | bit;
      numero <<= 1;
    }

    return primeiroByte;
  }

  public static int retornaPrimeiroByte2(int numero) {
    int primeiroByte = 0;

    int displayMask = 1 << 31;
    for (int i = 1; i <= 8; i++) {
      int bit = (numero & displayMask) == 0 ? 0 : 1;
      primeiroByte <<= 1;
      primeiroByte = primeiroByte | bit;
      numero <<= 1;
    }

    return primeiroByte;
  }

  public static boolean potenciaDeDois(int valor) {
    return valor > 0 && ((valor & (valor - 1)) == 0);
  } 

  public static int[] desfazVetorBits(int[] vetorBits) {
    int tamanho = ((vetorBits.length % 32) == 0) ? 0 : 1;
    tamanho += (int) (vetorBits.length / 32);
    int[] vetor = new int[tamanho];
    for (int i = 0, j = 0; j < tamanho; j++) {
      int mascara = 1 << 31;
      for (int bit = 1; bit <= 32; bit++, i++) {
        if (i >= vetorBits.length)
          break;
        if (vetorBits[i] == 1)
          vetor[j] = mascara | vetor[j];
        mascara >>>= 1;
      } 
    } 
    return vetor;
  } 

  public static int devolveERRO() {
    int erro = 0;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 1;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 1;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 1;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 1;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 1;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 1;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 1;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 1;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 1;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 1;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 0;
    erro <<= 1;
    erro |= 1;
    erro <<= 1;
    erro |= 1;
    erro <<= 1;
    erro |= 1;
    erro <<= 1;
    erro |= 1;
    return erro;
  }

  public static int devolveCrc() {
    int crc = 0;
    crc <<= 1;
    crc |= 1;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 1;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 1;
    crc <<= 1;
    crc |= 1;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 1;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 1;
    crc <<= 1;
    crc |= 1;
    crc <<= 1;
    crc |= 1;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 1;
    crc <<= 1;
    crc |= 1;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 1;
    crc <<= 1;
    crc |= 1;
    crc <<= 1;
    crc |= 0;
    crc <<= 1;
    crc |= 1;
    crc <<= 1;
    crc |= 1;
    return crc;
  }

  public static int moverBitsEsquerda(int numero) {
    numero <<= (32 - retornaBitsSignificativos(numero));
    return numero;
  }

  public static int retornaBitsSignificativos(int numero) {
    int numeroDeBits = Integer.toBinaryString(numero).length();
    if (numeroDeBits <= 8) { 
      numeroDeBits = 8;
    } else if (numeroDeBits <= 16) {
      numeroDeBits = 16;
    } else if (numeroDeBits <= 24) {
      numeroDeBits = 24;
    } else if (numeroDeBits <= 32) {
      numeroDeBits = 32;
    }
    return numeroDeBits;
  }

  
  public static int retornaBytesSignificativos(int numero) {
    int numeroDeBits = Integer.toBinaryString(numero).length();
    int numeroDeBytes = 0;
    if (numeroDeBits <= 8) { 
      numeroDeBytes = 1;
    } else if (numeroDeBits <= 16) {
      numeroDeBytes = 2;
    } else if (numeroDeBits <= 24) {
      numeroDeBytes = 3;
    } else if (numeroDeBits <= 32) {
      numeroDeBytes = 4;
    }
    return numeroDeBytes;
  }

 
  public static Boolean verificaCincoBitsSequenciais(int numero, int bit) {
    numero = MetodosBit.moverBitsEsquerda(numero);
    int displayMask = 1 << 31;
    Boolean bitsSequenciais = false;
    for (int cont = 1, contador = 0; cont <= 8; cont++) {
      int inteiroBit = (numero & displayMask) == 0 ? 0 : 1;
      if (inteiroBit == bit) {
        contador++;
      } else {
        contador = 0;
      }
      if (contador == 5) {
        bitsSequenciais = true;
      }
      numero <<= 1;
    }
    return bitsSequenciais;
  }

  public static int inverteBit(int[] vetor, int numero, int posicao) {
    int novoNumero = 0;

    if (posicao > 0 && posicao <= 32) {
      int displayMask = 1 << 31;
      for (int i = 1; i <= 32; i++) {
        int bit = (numero & displayMask) == 0 ? 0 : 1;
        novoNumero <<= 1;
        if (i == posicao) {
          novoNumero |= (bit == 1) ? 0 : 1;
        } else {
          novoNumero |= bit;
        }
        numero <<= 1;
      }
    } else {
      System.out.println("posicao [" + posicao + "] nao eh valida");
    }

    return novoNumero;
  }

  public static int[] inverteBits(int[] vetor, int indice, int onde) {
    vetor[indice] = inverteBits(vetor[indice], onde);
    return vetor;
  }

  private static int inverteBits(int i, int onde) {
    return 0;
  }

  public static int colocarBitNaPosicao(int numero, int adBit, int posicao) {
    int novoNumero = 0;
    if (posicao > 0 && posicao <= 32) {
      int displayMask = 1 << 31;
      for (int i = 1; i <= 32; i++) {
        int bit = (numero & displayMask) == 0 ? 0 : 1;
        novoNumero <<= 1;
        if (i == posicao) {
          novoNumero |= adBit;
        } else {
          novoNumero |= bit;
        }
        numero <<= 1;
      }

    } else {
      System.out.println("Erro: a poiscao [" + posicao + "] nao eh valida");
    }
    return novoNumero;
  }

  public static int retornarBitNaPosicao(int numero, int posicao) {
    int novoNumero = 0;
    if (posicao >= 0 && posicao < 32) {
      int displayMask = 1 << 31;
      for (int i = 0; i < 32; i++) {
        int bit = (numero & displayMask) == 0 ? 0 : 1;
        novoNumero <<= 1;
        if (i == posicao) {
          return bit;
        } else {
          novoNumero |= bit;
        }
        numero <<= 1;
      }

    } else {
      System.out.println("Erro: a posicao [" + posicao + "] nao eh valida");
    }
    return novoNumero;
  }

  public static int numeroDeBitsUm(int[] vetor) {
    int bits1 = 0;
    int displayMask = 1 << 31;
    for (int numero : vetor) {
      int quantBits = retornaBitsSignificativos(numero);
      numero = moverBitsEsquerda(numero);
      for (int i = 1; i <= quantBits; i++) {
        bits1 += (numero & displayMask) == 0 ? 0 : 1;
        numero <<= 1;
      }

    }
    return bits1;
  }

  public static int quantidadeBits1Inteiro(int inteiro) {
    int bits1 = 0;
    int displayMask = 1 << 31;
    int cont = 0;
    int bit = 0;
    while (cont < 32) {
      bit = (inteiro & displayMask) == 0 ? 0 : 1;
      bits1 += bit;
      cont++;
      inteiro <<= 1;
    }
    return bits1;
  }

}